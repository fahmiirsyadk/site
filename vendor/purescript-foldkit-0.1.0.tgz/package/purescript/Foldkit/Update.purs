module Foldkit.Update where

import Prelude

import Data.Foldable (foldl)
import Data.Maybe (Maybe(..))
import Foldkit.Command (Command)
import Foldkit.Command as Command

type Return model message =
  { model :: model
  , commands :: Array (Command message)
  }

type ReturnWithOut model message outMessage =
  { model :: model
  , commands :: Array (Command message)
  , outMessage :: Maybe outMessage
  }

type Step model message = model -> Return model message

noCommands :: forall model message. model -> Return model message
noCommands model = { model, commands: [] }

withCommand :: forall model message. model -> Command message -> Return model message
withCommand model command = { model, commands: [ command ] }

withCommands :: forall model message. model -> Array (Command message) -> Return model message
withCommands model commands = { model, commands }

mapCommands
  :: forall model childMessage parentMessage
   . (childMessage -> parentMessage)
  -> Return model childMessage
  -> Return model parentMessage
mapCommands toParent result =
  { model: result.model
  , commands: map (\command -> Command.mapMessage command toParent) result.commands
  }

combine :: forall model message. model -> Array (Step model message) -> Return model message
combine model steps = foldl next (noCommands model) steps
  where
  next current step =
    let result = step current.model
    in { model: result.model, commands: current.commands <> result.commands }

type ChildFold parentModel parentMessage childModel input childMessage =
  { update :: childModel -> input -> Return childModel childMessage
  , read :: parentModel -> Maybe childModel
  , write :: parentModel -> childModel -> parentModel
  , toParentMessage :: childMessage -> parentMessage
  }

foldChild
  :: forall parentModel parentMessage childModel input childMessage
   . ChildFold parentModel parentMessage childModel input childMessage
  -> parentModel
  -> input
  -> Return parentModel parentMessage
foldChild config model input = case config.read model of
  Nothing -> noCommands model
  Just childModel ->
    let childResult = config.update childModel input
        parentResult = mapCommands config.toParentMessage childResult
    in parentResult { model = config.write model childResult.model }

type ChildStepFold parentModel parentMessage childModel childMessage =
  { update :: childModel -> Return childModel childMessage
  , read :: parentModel -> Maybe childModel
  , write :: parentModel -> childModel -> parentModel
  , toParentMessage :: childMessage -> parentMessage
  }

foldChildStep
  :: forall parentModel parentMessage childModel childMessage
   . ChildStepFold parentModel parentMessage childModel childMessage
  -> Step parentModel parentMessage
foldChildStep config model = foldChild
  { update: \childModel _ -> config.update childModel
  , read: config.read
  , write: config.write
  , toParentMessage: config.toParentMessage
  }
  model
  unit

withOutMessage
  :: forall model message outMessage
   . Return model message
  -> Maybe outMessage
  -> ReturnWithOut model message outMessage
withOutMessage result outMessage =
  { model: result.model
  , commands: result.commands
  , outMessage
  }
