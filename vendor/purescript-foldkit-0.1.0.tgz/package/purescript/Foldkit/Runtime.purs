module Foldkit.Runtime
  ( Url
  , UrlRequest(..)
  , Application
  , run
  ) where

import Prelude

import Data.Function.Uncurried (mkFn1, mkFn2, runFn1)
import Data.Maybe (Maybe(..), fromMaybe, maybe)
import Foldkit.Document (Document, languageCode)
import Foldkit.Html (render)
import Foldkit.Raw.Runtime as Raw
import Foldkit.Update (Return)
import PursTs.Effect as Fx

type Url =
  { protocol :: String
  , host :: String
  , port :: Maybe String
  , pathname :: String
  , search :: Maybe String
  , hash :: Maybe String
  }

data UrlRequest
  = Internal { url :: Url }
  | External { href :: String }

type Application model message =
  { init :: Url -> Return model message
  , update :: model -> message -> Return model message
  , view :: model -> Document message
  , onUrlRequest :: UrlRequest -> message
  , onUrlChange :: Url -> message
  }

toUrl :: Raw.RawUrl -> Url
toUrl raw =
  { protocol: raw.protocol
  , host: raw.host
  , port: if raw.hasPort then Just raw.port else Nothing
  , pathname: raw.pathname
  , search: if raw.hasSearch then Just raw.search else Nothing
  , hash: if raw.hasHash then Just raw.hash else Nothing
  }

toUrlRequest :: Raw.RawUrlRequest -> UrlRequest
toUrlRequest raw = if raw.requestTag == "Internal" then
  Internal { url: toUrl raw.url }
else
  External { href: raw.href }

run
  :: forall model message
   . Application model message
  -> Fx.Effect Fx.Never Fx.NoServices Unit
run app = runFn1 Raw.runImpl
  { init: mkFn1 (app.init <<< toUrl)
  , update: mkFn2 app.update
  , view: mkFn2 \model builder ->
      let document = app.view model
      in { title: document.title
         , language: maybe "" languageCode document.language
         , hasLanguage: case document.language of
             Nothing -> false
             Just _ -> true
         , canonical: fromMaybe "" document.canonical
         , hasCanonical: case document.canonical of
             Nothing -> false
             Just _ -> true
         , openGraphUrl: fromMaybe "" document.openGraphUrl
         , hasOpenGraphUrl: case document.openGraphUrl of
             Nothing -> false
             Just _ -> true
         , body: render builder document.body
         }
  , onUrlRequest: mkFn1 (app.onUrlRequest <<< toUrlRequest)
  , onUrlChange: mkFn1 (app.onUrlChange <<< toUrl)
  }
