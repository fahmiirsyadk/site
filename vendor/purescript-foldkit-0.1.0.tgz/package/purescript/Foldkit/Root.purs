module Foldkit.Root
  ( toggleClass
  , setColorScheme
  ) where

import Prelude
import Data.Function.Uncurried (runFn2)
import PursTs.Effect as Fx
import Foldkit.Raw.Root as Raw

toggleClass
  :: String -> Boolean -> Fx.Effect Fx.Never Fx.NoServices Unit
toggleClass className enabled = runFn2 Raw.toggleClassImpl className enabled

setColorScheme
  :: String -> Fx.Effect Fx.Never Fx.NoServices Unit
setColorScheme = Raw.setColorSchemeImpl
