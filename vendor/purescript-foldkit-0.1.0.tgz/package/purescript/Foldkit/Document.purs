module Foldkit.Document
  ( Language(..)
  , language
  , Document
  , document
  , withCanonical
  , withOpenGraphUrl
  , withLanguage
  , languageCode
  ) where

import Prelude

import Data.Maybe (Maybe(..))
import Foldkit.Html (Child)

newtype Language = Language String

type Document message =
  { title :: String
  , language :: Maybe Language
  , canonical :: Maybe String
  , openGraphUrl :: Maybe String
  , body :: Child message
  }

language :: String -> Language
language = Language

languageCode :: Language -> String
languageCode (Language value) = value

document
  :: forall message
   . { title :: String, body :: Child message }
  -> Document message
document input =
  { title: input.title
  , language: Nothing
  , canonical: Nothing
  , openGraphUrl: Nothing
  , body: input.body
  }

withCanonical :: forall message. String -> Document message -> Document message
withCanonical value input = input { canonical = Just value }

withOpenGraphUrl :: forall message. String -> Document message -> Document message
withOpenGraphUrl value input = input { openGraphUrl = Just value }

withLanguage :: forall message. Language -> Document message -> Document message
withLanguage value input = input { language = Just value }
