module Foldkit.Navigation
  ( pushUrl
  , load
  ) where

import Prelude
import PursTs.Effect as Fx
import Foldkit.Raw.Navigation as Raw

pushUrl
  :: String -> Fx.Effect Fx.Never Fx.NoServices Unit
pushUrl = Raw.pushUrlImpl

load
  :: String -> Fx.Effect Fx.Never Fx.NoServices Unit
load = Raw.loadImpl
