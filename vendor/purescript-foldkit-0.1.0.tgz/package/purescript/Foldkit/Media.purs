module Foldkit.Media
  ( prefersReducedMotion
  , prefersDarkColorScheme
  ) where

import Prelude
import PursTs.Effect as Fx
import Foldkit.Raw.Media as Raw

prefersReducedMotion
  :: Fx.Effect Fx.Never Fx.NoServices Boolean
prefersReducedMotion = Raw.prefersReducedMotionImpl

prefersDarkColorScheme
  :: Fx.Effect Fx.Never Fx.NoServices Boolean
prefersDarkColorScheme = Raw.prefersDarkColorSchemeImpl
