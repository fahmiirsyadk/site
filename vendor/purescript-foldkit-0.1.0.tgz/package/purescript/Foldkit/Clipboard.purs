module Foldkit.Clipboard
  ( ClipboardError
  , writeText
  ) where

import Prelude
import Foldkit.Raw.Clipboard as Raw
import PursTs.Effect as Fx

type ClipboardError = Raw.ClipboardError

writeText
  :: String -> Fx.Effect ClipboardError Fx.NoServices Unit
writeText = Raw.writeTextImpl
