module Foldkit.Command where

import Prelude

import Data.Function.Uncurried (mkFn1, runFn2, runFn3)
import Foldkit.Raw.Command as Raw
import PursTs.Effect as Fx

type Command message = Raw.Command message

named
  :: forall row message
   . String
  -> { | row }
  -> (Unit -> Fx.Effect Fx.Never Fx.NoServices message)
  -> Command message
named name args factory = runFn3 Raw.namedImpl name args (mkFn1 factory)

namedNoArgs
  :: forall message
   . String
  -> (Unit -> Fx.Effect Fx.Never Fx.NoServices message)
  -> Command message
namedNoArgs name factory = runFn2 Raw.namedNoArgsImpl name (mkFn1 factory)

mapMessage
  :: forall message nextMessage
   . Command message
  -> (message -> nextMessage)
  -> Command nextMessage
mapMessage command mapper = runFn2 Raw.mapMessageImpl command mapper
