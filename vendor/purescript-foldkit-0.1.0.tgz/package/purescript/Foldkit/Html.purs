-- Generated from foldkit/dist/html/index.d.ts. Do not edit.
module Foldkit.Html
  ( module Types
  , element
  , keyed
  , empty
  , text
  , a
  , abbr
  , address
  , area
  , article
  , aside
  , audio
  , b
  , base
  , bdi
  , bdo
  , blockquote
  , body
  , br
  , button
  , canvas
  , caption
  , cite
  , code
  , col
  , colgroup
  , dataElement
  , datalist
  , dd
  , del
  , details
  , dfn
  , dialog
  , div
  , dl
  , dt
  , em
  , embed
  , fieldset
  , figcaption
  , figure
  , footer
  , form
  , h1
  , h2
  , h3
  , h4
  , h5
  , h6
  , head
  , header
  , hgroup
  , hr
  , html
  , i
  , iframe
  , img
  , input
  , ins
  , kbd
  , label
  , legend
  , li
  , link
  , main
  , map
  , mark
  , menu
  , meta
  , meter
  , nav
  , noscript
  , object
  , ol
  , optgroup
  , option
  , output
  , p
  , picture
  , portal
  , pre
  , progress
  , q
  , rp
  , rt
  , ruby
  , s
  , samp
  , script
  , search
  , section
  , select
  , slot
  , small
  , source
  , span
  , strong
  , style
  , sub
  , summary
  , sup
  , table
  , tbody
  , td
  , template
  , textarea
  , tfoot
  , th
  , thead
  , time
  , title
  , tr
  , track
  , u
  , ul
  , varElement
  , video
  , wbr
  , svg
  , animate
  , animateMotion
  , animateTransform
  , circle
  , clipPath
  , defs
  , desc
  , ellipse
  , feBlend
  , feColorMatrix
  , feComponentTransfer
  , feComposite
  , feConvolveMatrix
  , feDiffuseLighting
  , feDisplacementMap
  , feDistantLight
  , feDropShadow
  , feFlood
  , feFuncA
  , feFuncB
  , feFuncG
  , feFuncR
  , feGaussianBlur
  , feImage
  , feMerge
  , feMergeNode
  , feMorphology
  , feOffset
  , fePointLight
  , feSpecularLighting
  , feSpotLight
  , feTile
  , feTurbulence
  , filter
  , foreignObject
  , g
  , image
  , line
  , linearGradient
  , marker
  , mask
  , metadata
  , mpath
  , path
  , pattern
  , polygon
  , polyline
  , radialGradient
  , rect
  , set
  , stop
  , switch
  , symbol
  , textElement
  , textPath
  , tspan
  , use
  , view
  , math
  , annotation
  , maction
  , menclose
  , merror
  , mfenced
  , mfrac
  , mglyph
  , mi
  , mlabeledtr
  , mlongdiv
  , mmultiscripts
  , mn
  , mo
  , mover
  , mpadded
  , mphantom
  , mprescripts
  , mroot
  , mrow
  , ms
  , mscarries
  , mscarry
  , msgroup
  , msline
  , mspace
  , msqrt
  , msrow
  , mstack
  , mstyle
  , msub
  , msubsup
  , msup
  , mtable
  , mtd
  , mtext
  , mtr
  , munder
  , munderover
  , semantics
  ) where

import Prelude
import Prelude as Prelude

import Data.Function.Uncurried (runFn1, runFn2)
import Foldkit.Html.Types (Child, Html, HtmlBuilder, Prop, RenderedChild, RenderedProp, child, prop, render, renderChild, renderProp)
import Foldkit.Html.Types as Types
import Foldkit.Raw.Html as Raw

element :: forall message. String -> Array (Prop message) -> Array (Child message) -> Child message
element tag attributes children = child \builder -> runFn2 Raw.elementImpl builder
  { tag
  , attributes: Prelude.map (renderProp builder) attributes
  , children: Prelude.map (renderChild builder) children
  }

keyed :: forall message. String -> String -> Array (Prop message) -> Array (Child message) -> Child message
keyed tag key attributes children = child \builder -> runFn2 Raw.keyedImpl builder
  { tag
  , key
  , attributes: Prelude.map (renderProp builder) attributes
  , children: Prelude.map (renderChild builder) children
  }

empty :: forall message. Child message
empty = child \builder -> runFn1 Raw.emptyImpl builder

text :: forall message. String -> Child message
text value = child \_ -> runFn1 Raw.textImpl value

a :: forall message. Array (Prop message) -> Array (Child message) -> Child message
a = element "a"

abbr :: forall message. Array (Prop message) -> Array (Child message) -> Child message
abbr = element "abbr"

address :: forall message. Array (Prop message) -> Array (Child message) -> Child message
address = element "address"

area :: forall message. Array (Prop message) -> Array (Child message) -> Child message
area = element "area"

article :: forall message. Array (Prop message) -> Array (Child message) -> Child message
article = element "article"

aside :: forall message. Array (Prop message) -> Array (Child message) -> Child message
aside = element "aside"

audio :: forall message. Array (Prop message) -> Array (Child message) -> Child message
audio = element "audio"

b :: forall message. Array (Prop message) -> Array (Child message) -> Child message
b = element "b"

base :: forall message. Array (Prop message) -> Array (Child message) -> Child message
base = element "base"

bdi :: forall message. Array (Prop message) -> Array (Child message) -> Child message
bdi = element "bdi"

bdo :: forall message. Array (Prop message) -> Array (Child message) -> Child message
bdo = element "bdo"

blockquote :: forall message. Array (Prop message) -> Array (Child message) -> Child message
blockquote = element "blockquote"

body :: forall message. Array (Prop message) -> Array (Child message) -> Child message
body = element "body"

br :: forall message. Array (Prop message) -> Array (Child message) -> Child message
br = element "br"

button :: forall message. Array (Prop message) -> Array (Child message) -> Child message
button = element "button"

canvas :: forall message. Array (Prop message) -> Array (Child message) -> Child message
canvas = element "canvas"

caption :: forall message. Array (Prop message) -> Array (Child message) -> Child message
caption = element "caption"

cite :: forall message. Array (Prop message) -> Array (Child message) -> Child message
cite = element "cite"

code :: forall message. Array (Prop message) -> Array (Child message) -> Child message
code = element "code"

col :: forall message. Array (Prop message) -> Array (Child message) -> Child message
col = element "col"

colgroup :: forall message. Array (Prop message) -> Array (Child message) -> Child message
colgroup = element "colgroup"

dataElement :: forall message. Array (Prop message) -> Array (Child message) -> Child message
dataElement = element "data"

datalist :: forall message. Array (Prop message) -> Array (Child message) -> Child message
datalist = element "datalist"

dd :: forall message. Array (Prop message) -> Array (Child message) -> Child message
dd = element "dd"

del :: forall message. Array (Prop message) -> Array (Child message) -> Child message
del = element "del"

details :: forall message. Array (Prop message) -> Array (Child message) -> Child message
details = element "details"

dfn :: forall message. Array (Prop message) -> Array (Child message) -> Child message
dfn = element "dfn"

dialog :: forall message. Array (Prop message) -> Array (Child message) -> Child message
dialog = element "dialog"

div :: forall message. Array (Prop message) -> Array (Child message) -> Child message
div = element "div"

dl :: forall message. Array (Prop message) -> Array (Child message) -> Child message
dl = element "dl"

dt :: forall message. Array (Prop message) -> Array (Child message) -> Child message
dt = element "dt"

em :: forall message. Array (Prop message) -> Array (Child message) -> Child message
em = element "em"

embed :: forall message. Array (Prop message) -> Array (Child message) -> Child message
embed = element "embed"

fieldset :: forall message. Array (Prop message) -> Array (Child message) -> Child message
fieldset = element "fieldset"

figcaption :: forall message. Array (Prop message) -> Array (Child message) -> Child message
figcaption = element "figcaption"

figure :: forall message. Array (Prop message) -> Array (Child message) -> Child message
figure = element "figure"

footer :: forall message. Array (Prop message) -> Array (Child message) -> Child message
footer = element "footer"

form :: forall message. Array (Prop message) -> Array (Child message) -> Child message
form = element "form"

h1 :: forall message. Array (Prop message) -> Array (Child message) -> Child message
h1 = element "h1"

h2 :: forall message. Array (Prop message) -> Array (Child message) -> Child message
h2 = element "h2"

h3 :: forall message. Array (Prop message) -> Array (Child message) -> Child message
h3 = element "h3"

h4 :: forall message. Array (Prop message) -> Array (Child message) -> Child message
h4 = element "h4"

h5 :: forall message. Array (Prop message) -> Array (Child message) -> Child message
h5 = element "h5"

h6 :: forall message. Array (Prop message) -> Array (Child message) -> Child message
h6 = element "h6"

head :: forall message. Array (Prop message) -> Array (Child message) -> Child message
head = element "head"

header :: forall message. Array (Prop message) -> Array (Child message) -> Child message
header = element "header"

hgroup :: forall message. Array (Prop message) -> Array (Child message) -> Child message
hgroup = element "hgroup"

hr :: forall message. Array (Prop message) -> Array (Child message) -> Child message
hr = element "hr"

html :: forall message. Array (Prop message) -> Array (Child message) -> Child message
html = element "html"

i :: forall message. Array (Prop message) -> Array (Child message) -> Child message
i = element "i"

iframe :: forall message. Array (Prop message) -> Array (Child message) -> Child message
iframe = element "iframe"

img :: forall message. Array (Prop message) -> Array (Child message) -> Child message
img = element "img"

input :: forall message. Array (Prop message) -> Array (Child message) -> Child message
input = element "input"

ins :: forall message. Array (Prop message) -> Array (Child message) -> Child message
ins = element "ins"

kbd :: forall message. Array (Prop message) -> Array (Child message) -> Child message
kbd = element "kbd"

label :: forall message. Array (Prop message) -> Array (Child message) -> Child message
label = element "label"

legend :: forall message. Array (Prop message) -> Array (Child message) -> Child message
legend = element "legend"

li :: forall message. Array (Prop message) -> Array (Child message) -> Child message
li = element "li"

link :: forall message. Array (Prop message) -> Array (Child message) -> Child message
link = element "link"

main :: forall message. Array (Prop message) -> Array (Child message) -> Child message
main = element "main"

map :: forall message. Array (Prop message) -> Array (Child message) -> Child message
map = element "map"

mark :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mark = element "mark"

menu :: forall message. Array (Prop message) -> Array (Child message) -> Child message
menu = element "menu"

meta :: forall message. Array (Prop message) -> Array (Child message) -> Child message
meta = element "meta"

meter :: forall message. Array (Prop message) -> Array (Child message) -> Child message
meter = element "meter"

nav :: forall message. Array (Prop message) -> Array (Child message) -> Child message
nav = element "nav"

noscript :: forall message. Array (Prop message) -> Array (Child message) -> Child message
noscript = element "noscript"

object :: forall message. Array (Prop message) -> Array (Child message) -> Child message
object = element "object"

ol :: forall message. Array (Prop message) -> Array (Child message) -> Child message
ol = element "ol"

optgroup :: forall message. Array (Prop message) -> Array (Child message) -> Child message
optgroup = element "optgroup"

option :: forall message. Array (Prop message) -> Array (Child message) -> Child message
option = element "option"

output :: forall message. Array (Prop message) -> Array (Child message) -> Child message
output = element "output"

p :: forall message. Array (Prop message) -> Array (Child message) -> Child message
p = element "p"

picture :: forall message. Array (Prop message) -> Array (Child message) -> Child message
picture = element "picture"

portal :: forall message. Array (Prop message) -> Array (Child message) -> Child message
portal = element "portal"

pre :: forall message. Array (Prop message) -> Array (Child message) -> Child message
pre = element "pre"

progress :: forall message. Array (Prop message) -> Array (Child message) -> Child message
progress = element "progress"

q :: forall message. Array (Prop message) -> Array (Child message) -> Child message
q = element "q"

rp :: forall message. Array (Prop message) -> Array (Child message) -> Child message
rp = element "rp"

rt :: forall message. Array (Prop message) -> Array (Child message) -> Child message
rt = element "rt"

ruby :: forall message. Array (Prop message) -> Array (Child message) -> Child message
ruby = element "ruby"

s :: forall message. Array (Prop message) -> Array (Child message) -> Child message
s = element "s"

samp :: forall message. Array (Prop message) -> Array (Child message) -> Child message
samp = element "samp"

script :: forall message. Array (Prop message) -> Array (Child message) -> Child message
script = element "script"

search :: forall message. Array (Prop message) -> Array (Child message) -> Child message
search = element "search"

section :: forall message. Array (Prop message) -> Array (Child message) -> Child message
section = element "section"

select :: forall message. Array (Prop message) -> Array (Child message) -> Child message
select = element "select"

slot :: forall message. Array (Prop message) -> Array (Child message) -> Child message
slot = element "slot"

small :: forall message. Array (Prop message) -> Array (Child message) -> Child message
small = element "small"

source :: forall message. Array (Prop message) -> Array (Child message) -> Child message
source = element "source"

span :: forall message. Array (Prop message) -> Array (Child message) -> Child message
span = element "span"

strong :: forall message. Array (Prop message) -> Array (Child message) -> Child message
strong = element "strong"

style :: forall message. Array (Prop message) -> Array (Child message) -> Child message
style = element "style"

sub :: forall message. Array (Prop message) -> Array (Child message) -> Child message
sub = element "sub"

summary :: forall message. Array (Prop message) -> Array (Child message) -> Child message
summary = element "summary"

sup :: forall message. Array (Prop message) -> Array (Child message) -> Child message
sup = element "sup"

table :: forall message. Array (Prop message) -> Array (Child message) -> Child message
table = element "table"

tbody :: forall message. Array (Prop message) -> Array (Child message) -> Child message
tbody = element "tbody"

td :: forall message. Array (Prop message) -> Array (Child message) -> Child message
td = element "td"

template :: forall message. Array (Prop message) -> Array (Child message) -> Child message
template = element "template"

textarea :: forall message. Array (Prop message) -> Array (Child message) -> Child message
textarea = element "textarea"

tfoot :: forall message. Array (Prop message) -> Array (Child message) -> Child message
tfoot = element "tfoot"

th :: forall message. Array (Prop message) -> Array (Child message) -> Child message
th = element "th"

thead :: forall message. Array (Prop message) -> Array (Child message) -> Child message
thead = element "thead"

time :: forall message. Array (Prop message) -> Array (Child message) -> Child message
time = element "time"

title :: forall message. Array (Prop message) -> Array (Child message) -> Child message
title = element "title"

tr :: forall message. Array (Prop message) -> Array (Child message) -> Child message
tr = element "tr"

track :: forall message. Array (Prop message) -> Array (Child message) -> Child message
track = element "track"

u :: forall message. Array (Prop message) -> Array (Child message) -> Child message
u = element "u"

ul :: forall message. Array (Prop message) -> Array (Child message) -> Child message
ul = element "ul"

varElement :: forall message. Array (Prop message) -> Array (Child message) -> Child message
varElement = element "var"

video :: forall message. Array (Prop message) -> Array (Child message) -> Child message
video = element "video"

wbr :: forall message. Array (Prop message) -> Array (Child message) -> Child message
wbr = element "wbr"

svg :: forall message. Array (Prop message) -> Array (Child message) -> Child message
svg = element "svg"

animate :: forall message. Array (Prop message) -> Array (Child message) -> Child message
animate = element "animate"

animateMotion :: forall message. Array (Prop message) -> Array (Child message) -> Child message
animateMotion = element "animateMotion"

animateTransform :: forall message. Array (Prop message) -> Array (Child message) -> Child message
animateTransform = element "animateTransform"

circle :: forall message. Array (Prop message) -> Array (Child message) -> Child message
circle = element "circle"

clipPath :: forall message. Array (Prop message) -> Array (Child message) -> Child message
clipPath = element "clipPath"

defs :: forall message. Array (Prop message) -> Array (Child message) -> Child message
defs = element "defs"

desc :: forall message. Array (Prop message) -> Array (Child message) -> Child message
desc = element "desc"

ellipse :: forall message. Array (Prop message) -> Array (Child message) -> Child message
ellipse = element "ellipse"

feBlend :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feBlend = element "feBlend"

feColorMatrix :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feColorMatrix = element "feColorMatrix"

feComponentTransfer :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feComponentTransfer = element "feComponentTransfer"

feComposite :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feComposite = element "feComposite"

feConvolveMatrix :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feConvolveMatrix = element "feConvolveMatrix"

feDiffuseLighting :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feDiffuseLighting = element "feDiffuseLighting"

feDisplacementMap :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feDisplacementMap = element "feDisplacementMap"

feDistantLight :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feDistantLight = element "feDistantLight"

feDropShadow :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feDropShadow = element "feDropShadow"

feFlood :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feFlood = element "feFlood"

feFuncA :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feFuncA = element "feFuncA"

feFuncB :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feFuncB = element "feFuncB"

feFuncG :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feFuncG = element "feFuncG"

feFuncR :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feFuncR = element "feFuncR"

feGaussianBlur :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feGaussianBlur = element "feGaussianBlur"

feImage :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feImage = element "feImage"

feMerge :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feMerge = element "feMerge"

feMergeNode :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feMergeNode = element "feMergeNode"

feMorphology :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feMorphology = element "feMorphology"

feOffset :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feOffset = element "feOffset"

fePointLight :: forall message. Array (Prop message) -> Array (Child message) -> Child message
fePointLight = element "fePointLight"

feSpecularLighting :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feSpecularLighting = element "feSpecularLighting"

feSpotLight :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feSpotLight = element "feSpotLight"

feTile :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feTile = element "feTile"

feTurbulence :: forall message. Array (Prop message) -> Array (Child message) -> Child message
feTurbulence = element "feTurbulence"

filter :: forall message. Array (Prop message) -> Array (Child message) -> Child message
filter = element "filter"

foreignObject :: forall message. Array (Prop message) -> Array (Child message) -> Child message
foreignObject = element "foreignObject"

g :: forall message. Array (Prop message) -> Array (Child message) -> Child message
g = element "g"

image :: forall message. Array (Prop message) -> Array (Child message) -> Child message
image = element "image"

line :: forall message. Array (Prop message) -> Array (Child message) -> Child message
line = element "line"

linearGradient :: forall message. Array (Prop message) -> Array (Child message) -> Child message
linearGradient = element "linearGradient"

marker :: forall message. Array (Prop message) -> Array (Child message) -> Child message
marker = element "marker"

mask :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mask = element "mask"

metadata :: forall message. Array (Prop message) -> Array (Child message) -> Child message
metadata = element "metadata"

mpath :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mpath = element "mpath"

path :: forall message. Array (Prop message) -> Array (Child message) -> Child message
path = element "path"

pattern :: forall message. Array (Prop message) -> Array (Child message) -> Child message
pattern = element "pattern"

polygon :: forall message. Array (Prop message) -> Array (Child message) -> Child message
polygon = element "polygon"

polyline :: forall message. Array (Prop message) -> Array (Child message) -> Child message
polyline = element "polyline"

radialGradient :: forall message. Array (Prop message) -> Array (Child message) -> Child message
radialGradient = element "radialGradient"

rect :: forall message. Array (Prop message) -> Array (Child message) -> Child message
rect = element "rect"

set :: forall message. Array (Prop message) -> Array (Child message) -> Child message
set = element "set"

stop :: forall message. Array (Prop message) -> Array (Child message) -> Child message
stop = element "stop"

switch :: forall message. Array (Prop message) -> Array (Child message) -> Child message
switch = element "switch"

symbol :: forall message. Array (Prop message) -> Array (Child message) -> Child message
symbol = element "symbol"

textElement :: forall message. Array (Prop message) -> Array (Child message) -> Child message
textElement = element "text"

textPath :: forall message. Array (Prop message) -> Array (Child message) -> Child message
textPath = element "textPath"

tspan :: forall message. Array (Prop message) -> Array (Child message) -> Child message
tspan = element "tspan"

use :: forall message. Array (Prop message) -> Array (Child message) -> Child message
use = element "use"

view :: forall message. Array (Prop message) -> Array (Child message) -> Child message
view = element "view"

math :: forall message. Array (Prop message) -> Array (Child message) -> Child message
math = element "math"

annotation :: forall message. Array (Prop message) -> Array (Child message) -> Child message
annotation = element "annotation"

maction :: forall message. Array (Prop message) -> Array (Child message) -> Child message
maction = element "maction"

menclose :: forall message. Array (Prop message) -> Array (Child message) -> Child message
menclose = element "menclose"

merror :: forall message. Array (Prop message) -> Array (Child message) -> Child message
merror = element "merror"

mfenced :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mfenced = element "mfenced"

mfrac :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mfrac = element "mfrac"

mglyph :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mglyph = element "mglyph"

mi :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mi = element "mi"

mlabeledtr :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mlabeledtr = element "mlabeledtr"

mlongdiv :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mlongdiv = element "mlongdiv"

mmultiscripts :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mmultiscripts = element "mmultiscripts"

mn :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mn = element "mn"

mo :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mo = element "mo"

mover :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mover = element "mover"

mpadded :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mpadded = element "mpadded"

mphantom :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mphantom = element "mphantom"

mprescripts :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mprescripts = element "mprescripts"

mroot :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mroot = element "mroot"

mrow :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mrow = element "mrow"

ms :: forall message. Array (Prop message) -> Array (Child message) -> Child message
ms = element "ms"

mscarries :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mscarries = element "mscarries"

mscarry :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mscarry = element "mscarry"

msgroup :: forall message. Array (Prop message) -> Array (Child message) -> Child message
msgroup = element "msgroup"

msline :: forall message. Array (Prop message) -> Array (Child message) -> Child message
msline = element "msline"

mspace :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mspace = element "mspace"

msqrt :: forall message. Array (Prop message) -> Array (Child message) -> Child message
msqrt = element "msqrt"

msrow :: forall message. Array (Prop message) -> Array (Child message) -> Child message
msrow = element "msrow"

mstack :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mstack = element "mstack"

mstyle :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mstyle = element "mstyle"

msub :: forall message. Array (Prop message) -> Array (Child message) -> Child message
msub = element "msub"

msubsup :: forall message. Array (Prop message) -> Array (Child message) -> Child message
msubsup = element "msubsup"

msup :: forall message. Array (Prop message) -> Array (Child message) -> Child message
msup = element "msup"

mtable :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mtable = element "mtable"

mtd :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mtd = element "mtd"

mtext :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mtext = element "mtext"

mtr :: forall message. Array (Prop message) -> Array (Child message) -> Child message
mtr = element "mtr"

munder :: forall message. Array (Prop message) -> Array (Child message) -> Child message
munder = element "munder"

munderover :: forall message. Array (Prop message) -> Array (Child message) -> Child message
munderover = element "munderover"

semantics :: forall message. Array (Prop message) -> Array (Child message) -> Child message
semantics = element "semantics"
