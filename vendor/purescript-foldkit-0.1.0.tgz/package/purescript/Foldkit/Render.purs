module Foldkit.Render
  ( afterPaint
  ) where

import Prelude
import PursTs.Effect as Fx
import Foldkit.Raw.Render as Raw

afterPaint
  :: Fx.Effect Fx.Never Fx.NoServices Unit
afterPaint = Raw.afterPaintImpl
