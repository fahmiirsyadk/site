module Foldkit.Raw.Mount where

import Prelude

import Data.Function.Uncurried (Fn1, Fn2, Fn3)
import PursTs.Effect as Fx

foreign import data Element :: Type

type MountAction :: Type -> Type
type MountAction message =
  { name :: String
  }

foreign import defineImpl
  :: forall message
   . Fn2 String (Fn1 Element (Fx.Effect Fx.Never Fx.Scope message)) (MountAction message)

foreign import defineWithImpl
  :: forall row message
   . Fn3 String { | row } (Fn2 { | row } Element (Fx.Effect Fx.Never Fx.Scope message)) (MountAction message)

foreign import mapMessageImpl
  :: forall message nextMessage
   . Fn3 (MountAction message) (message -> nextMessage) Unit (MountAction nextMessage)
