module Foldkit.Raw.Media where

import Prelude
import PursTs.Effect as Fx

foreign import prefersReducedMotionImpl
  :: Fx.Effect Fx.Never Fx.NoServices Boolean

foreign import prefersDarkColorSchemeImpl
  :: Fx.Effect Fx.Never Fx.NoServices Boolean
