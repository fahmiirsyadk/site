module Foldkit.Raw.Command where

import Prelude

import Data.Function.Uncurried (Fn1, Fn2, Fn3)
import PursTs.Effect as Fx

type Command message =
  { name :: String
  , effect :: Fx.Effect Fx.Never Fx.NoServices message
  }

foreign import namedImpl
  :: forall row message
   . Fn3 String { | row } (Fn1 Unit (Fx.Effect Fx.Never Fx.NoServices message)) (Command message)

foreign import namedNoArgsImpl
  :: forall message
   . Fn2 String (Fn1 Unit (Fx.Effect Fx.Never Fx.NoServices message)) (Command message)

foreign import mapMessageImpl
  :: forall message nextMessage
   . Fn3 (Command message) (message -> nextMessage) Unit (Command nextMessage)
