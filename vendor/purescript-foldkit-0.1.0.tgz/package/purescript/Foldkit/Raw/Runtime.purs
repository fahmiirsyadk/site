module Foldkit.Raw.Runtime where

import Prelude

import Data.Function.Uncurried (Fn1, Fn2)
import Foldkit.Html.Types (Html, HtmlBuilder)
import Foldkit.Update (Return)
import PursTs.Effect as Fx

type RawUrl =
  { protocol :: String
  , host :: String
  , port :: String
  , hasPort :: Boolean
  , pathname :: String
  , search :: String
  , hasSearch :: Boolean
  , hash :: String
  , hasHash :: Boolean
  }

type RawUrlRequest =
  { requestTag :: String
  , url :: RawUrl
  , href :: String
  }

type RenderedDocument message =
  { title :: String
  , language :: String
  , hasLanguage :: Boolean
  , canonical :: String
  , hasCanonical :: Boolean
  , openGraphUrl :: String
  , hasOpenGraphUrl :: Boolean
  , body :: Html message
  }

type RuntimeApplication model message =
  { init :: Fn1 RawUrl (Return model message)
  , update :: Fn2 model message (Return model message)
  , view :: Fn2 model (HtmlBuilder message) (RenderedDocument message)
  , onUrlRequest :: Fn1 RawUrlRequest message
  , onUrlChange :: Fn1 RawUrl message
  }

foreign import runImpl
  :: forall model message
   . Fn1 (RuntimeApplication model message) (Fx.Effect Fx.Never Fx.NoServices Unit)
