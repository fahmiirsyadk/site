module Foldkit.Raw.Root where

import Prelude
import Data.Function.Uncurried (Fn2)
import PursTs.Effect as Fx

foreign import toggleClassImpl
  :: Fn2 String Boolean (Fx.Effect Fx.Never Fx.NoServices Unit)

foreign import setColorSchemeImpl
  :: String -> Fx.Effect Fx.Never Fx.NoServices Unit
