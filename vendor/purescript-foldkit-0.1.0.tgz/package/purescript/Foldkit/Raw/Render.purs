module Foldkit.Raw.Render where

import Prelude
import PursTs.Effect as Fx

foreign import afterPaintImpl
  :: Fx.Effect Fx.Never Fx.NoServices Unit
