module Foldkit.Raw.Clipboard where

import Prelude
import PursTs.Effect as Fx

foreign import data ClipboardError :: Type

foreign import writeTextImpl
  :: String -> Fx.Effect ClipboardError Fx.NoServices Unit
