module Foldkit.Raw.Storage where

import Prelude
import Data.Function.Uncurried (Fn2)
import PursTs.Effect as Fx

foreign import data StorageError :: Type

type ReadResult =
  { found :: Boolean
  , value :: String
  }

foreign import readImpl
  :: String -> Fx.Effect StorageError Fx.NoServices ReadResult

foreign import writeImpl
  :: Fn2 String String (Fx.Effect StorageError Fx.NoServices Unit)
