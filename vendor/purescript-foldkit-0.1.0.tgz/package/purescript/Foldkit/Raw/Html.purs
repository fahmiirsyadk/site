module Foldkit.Raw.Html where

import Data.Function.Uncurried (Fn1, Fn2, Fn3, Fn4, Fn7)
import Data.Maybe (Maybe)

foreign import data HtmlBuilder :: Type -> Type
foreign import data Html :: Type -> Type
foreign import data RenderedProp :: Type -> Type
foreign import data RenderedChild :: Type -> Type

type RenderedElementInput message =
  { tag :: String
  , attributes :: Array (RenderedProp message)
  , children :: Array (RenderedChild message)
  }

type RenderedKeyedInput message =
  { tag :: String
  , key :: String
  , attributes :: Array (RenderedProp message)
  , children :: Array (RenderedChild message)
  }

type RawSubmodelInput model childMessage parentMessage =
  { slotId :: String
  , model :: model
  , view :: Fn2 model (HtmlBuilder childMessage) (RenderedChild childMessage)
  , toParentMessage :: childMessage -> parentMessage
  }

foreign import emptyImpl :: forall message. Fn1 (HtmlBuilder message) (RenderedChild message)
foreign import elementImpl :: forall message. Fn2 (HtmlBuilder message) (RenderedElementInput message) (RenderedChild message)
foreign import keyedImpl :: forall message. Fn2 (HtmlBuilder message) (RenderedKeyedInput message) (RenderedChild message)
foreign import prop0Impl :: forall message. Fn2 (HtmlBuilder message) String (RenderedProp message)
foreign import prop1Impl :: forall value message. Fn3 (HtmlBuilder message) String value (RenderedProp message)
foreign import prop2Impl :: forall left right message. Fn4 (HtmlBuilder message) String left right (RenderedProp message)
foreign import propAriaCheckedImpl :: forall value message. Fn3 (HtmlBuilder message) String value (RenderedProp message)
foreign import propMaybe1Impl :: forall value message argument. Fn3 (HtmlBuilder message) String (Fn1 argument (Maybe value)) (RenderedProp message)
foreign import propMaybe2Impl :: forall value message argument1 argument2. Fn3 (HtmlBuilder message) String (Fn2 argument1 argument2 (Maybe value)) (RenderedProp message)
foreign import propMaybe3Impl :: forall value message argument1 argument2 argument3. Fn3 (HtmlBuilder message) String (Fn3 argument1 argument2 argument3 (Maybe value)) (RenderedProp message)
foreign import propMaybe4Impl :: forall value message argument1 argument2 argument3 argument4. Fn3 (HtmlBuilder message) String (Fn4 argument1 argument2 argument3 argument4 (Maybe value)) (RenderedProp message)
foreign import propMaybe7Impl :: forall value message argument1 argument2 argument3 argument4 argument5 argument6 argument7. Fn3 (HtmlBuilder message) String (Fn7 argument1 argument2 argument3 argument4 argument5 argument6 argument7 (Maybe value)) (RenderedProp message)
foreign import rootImpl :: forall message. Fn1 (RenderedChild message) (Html message)
foreign import submodelImpl :: forall model childMessage parentMessage. Fn2 (HtmlBuilder parentMessage) (RawSubmodelInput model childMessage parentMessage) (RenderedChild parentMessage)
foreign import textImpl :: forall message. Fn1 String (RenderedChild message)
