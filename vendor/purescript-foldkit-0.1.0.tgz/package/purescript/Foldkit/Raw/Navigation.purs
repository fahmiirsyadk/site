module Foldkit.Raw.Navigation where

import Prelude
import PursTs.Effect as Fx

foreign import pushUrlImpl
  :: String -> Fx.Effect Fx.Never Fx.NoServices Unit

foreign import loadImpl
  :: String -> Fx.Effect Fx.Never Fx.NoServices Unit
