module Foldkit.Mount where

import Prelude

import Data.Function.Uncurried (mkFn1, mkFn2, runFn2, runFn3)
import Foldkit.Raw.Mount as Raw
import PursTs.Effect as Fx

type Element = Raw.Element

type MountAction :: Type -> Type
type MountAction message = Raw.MountAction message

define
  :: forall message
   . String
  -> (Element -> Fx.Effect Fx.Never Fx.Scope message)
  -> MountAction message
define name factory = runFn2 Raw.defineImpl name (mkFn1 factory)

defineWith
  :: forall row message
   . String
  -> { | row }
  -> ({ | row } -> Element -> Fx.Effect Fx.Never Fx.Scope message)
  -> MountAction message
defineWith name args factory = runFn3 Raw.defineWithImpl name args (mkFn2 factory)

mapMessage
  :: forall message nextMessage
   . MountAction message
  -> (message -> nextMessage)
  -> MountAction nextMessage
mapMessage action mapper = runFn3 Raw.mapMessageImpl action mapper unit
