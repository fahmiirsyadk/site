module Foldkit.Submodel (submodel) where

import Data.Function.Uncurried (mkFn2, runFn2)
import Foldkit.Html.Types (Child, child, renderChild)
import Foldkit.Raw.Html as Raw

submodel
  :: forall model childMessage parentMessage
   . { slotId :: String
     , model :: model
     , view :: model -> Child childMessage
     , toParentMessage :: childMessage -> parentMessage
     }
  -> Child parentMessage
submodel input = child \builder -> runFn2 Raw.submodelImpl builder
  { slotId: input.slotId
  , model: input.model
  , view: mkFn2 \model childBuilder -> renderChild childBuilder (input.view model)
  , toParentMessage: input.toParentMessage
  }
