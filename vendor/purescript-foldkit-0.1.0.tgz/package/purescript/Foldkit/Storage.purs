module Foldkit.Storage
  ( StorageError
  , get
  , set
  ) where

import Prelude
import Data.Maybe (Maybe(..))
import Data.Function.Uncurried (runFn2)
import Foldkit.Raw.Storage as Raw
import PursTs.Effect as Fx

type StorageError = Raw.StorageError

get
  :: String -> Fx.Effect StorageError Fx.NoServices (Maybe String)
get key = Fx.map (Raw.readImpl key) \result ->
  if result.found then Just result.value else Nothing

set
  :: String -> String -> Fx.Effect StorageError Fx.NoServices Unit
set key value = runFn2 Raw.writeImpl key value
