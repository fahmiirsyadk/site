-- Generated from foldkit/dist/html/index.d.ts. Do not edit.
module Foldkit.Html.Prop where

import Prelude

import Data.Function.Uncurried (mkFn1, mkFn2, mkFn3, mkFn4, mkFn7, runFn2, runFn3, runFn4)
import Data.Maybe (Maybe)
import Foldkit.Html.Types (Prop, prop)
import Foldkit.Mount (MountAction)
import Foldkit.Raw.Html as Raw

foreign import data File :: Type

type KeyboardModifiers =
  { shiftKey :: Boolean
  , ctrlKey :: Boolean
  , altKey :: Boolean
  , metaKey :: Boolean
  }

data AriaChecked
  = AriaBoolean Boolean
  | AriaMixed

key :: forall message. String -> Prop message
key value = prop \builder -> runFn3 Raw.prop1Impl builder "Key" value

class_ :: forall message. String -> Prop message
class_ value = prop \builder -> runFn3 Raw.prop1Impl builder "Class" value

id :: forall message. String -> Prop message
id value = prop \builder -> runFn3 Raw.prop1Impl builder "Id" value

title :: forall message. String -> Prop message
title value = prop \builder -> runFn3 Raw.prop1Impl builder "Title" value

lang :: forall message. String -> Prop message
lang value = prop \builder -> runFn3 Raw.prop1Impl builder "Lang" value

dir :: forall message. String -> Prop message
dir value = prop \builder -> runFn3 Raw.prop1Impl builder "Dir" value

tabindex :: forall message. Number -> Prop message
tabindex value = prop \builder -> runFn3 Raw.prop1Impl builder "Tabindex" value

hidden :: forall message. Boolean -> Prop message
hidden value = prop \builder -> runFn3 Raw.prop1Impl builder "Hidden" value

contenteditable :: forall message. String -> Prop message
contenteditable value = prop \builder -> runFn3 Raw.prop1Impl builder "Contenteditable" value

draggable :: forall message. Boolean -> Prop message
draggable value = prop \builder -> runFn3 Raw.prop1Impl builder "Draggable" value

accesskey :: forall message. String -> Prop message
accesskey value = prop \builder -> runFn3 Raw.prop1Impl builder "Accesskey" value

translate :: forall message. String -> Prop message
translate value = prop \builder -> runFn3 Raw.prop1Impl builder "Translate" value

inert :: forall message. Boolean -> Prop message
inert value = prop \builder -> runFn3 Raw.prop1Impl builder "Inert" value

popover :: forall message. String -> Prop message
popover value = prop \builder -> runFn3 Raw.prop1Impl builder "Popover" value

popovertarget :: forall message. String -> Prop message
popovertarget value = prop \builder -> runFn3 Raw.prop1Impl builder "Popovertarget" value

popovertargetaction :: forall message. String -> Prop message
popovertargetaction value = prop \builder -> runFn3 Raw.prop1Impl builder "Popovertargetaction" value

onClick :: forall message. { message :: message } -> Prop message
onClick input = prop \builder -> runFn3 Raw.prop1Impl builder "OnClick" input.message

onClickFocus :: forall message. { focusSelector :: String, message :: message } -> Prop message
onClickFocus input = prop \builder -> runFn4 Raw.prop2Impl builder "OnClickFocus" input.focusSelector input.message

onDoubleClick :: forall message. { message :: message } -> Prop message
onDoubleClick input = prop \builder -> runFn3 Raw.prop1Impl builder "OnDoubleClick" input.message

onMouseDown :: forall message. { message :: message } -> Prop message
onMouseDown input = prop \builder -> runFn3 Raw.prop1Impl builder "OnMouseDown" input.message

onMouseUp :: forall message. { message :: message } -> Prop message
onMouseUp input = prop \builder -> runFn3 Raw.prop1Impl builder "OnMouseUp" input.message

onMouseEnter :: forall message. { message :: message } -> Prop message
onMouseEnter input = prop \builder -> runFn3 Raw.prop1Impl builder "OnMouseEnter" input.message

onMouseLeave :: forall message. { message :: message } -> Prop message
onMouseLeave input = prop \builder -> runFn3 Raw.prop1Impl builder "OnMouseLeave" input.message

onMouseOver :: forall message. { message :: message } -> Prop message
onMouseOver input = prop \builder -> runFn3 Raw.prop1Impl builder "OnMouseOver" input.message

onMouseOut :: forall message. { message :: message } -> Prop message
onMouseOut input = prop \builder -> runFn3 Raw.prop1Impl builder "OnMouseOut" input.message

onMouseMove :: forall message. { message :: message } -> Prop message
onMouseMove input = prop \builder -> runFn3 Raw.prop1Impl builder "OnMouseMove" input.message

onPointerMove :: forall message. (Number -> Number -> String -> Maybe (message)) -> Prop message
onPointerMove callback = prop \builder -> runFn3 Raw.propMaybe3Impl builder "OnPointerMove" (mkFn3 \screenX screenY pointerType -> callback screenX screenY pointerType)

onPointerLeave :: forall message. (String -> Maybe (message)) -> Prop message
onPointerLeave callback = prop \builder -> runFn3 Raw.propMaybe1Impl builder "OnPointerLeave" (mkFn1 \pointerType -> callback pointerType)

onPointerDown :: forall message. (String -> Number -> Number -> Number -> Number -> Number -> Number -> Maybe (message)) -> Prop message
onPointerDown callback = prop \builder -> runFn3 Raw.propMaybe7Impl builder "OnPointerDown" (mkFn7 \pointerType button screenX screenY timeStamp clientX clientY -> callback pointerType button screenX screenY timeStamp clientX clientY)

onPointerUp :: forall message. (Number -> Number -> String -> Number -> Maybe (message)) -> Prop message
onPointerUp callback = prop \builder -> runFn3 Raw.propMaybe4Impl builder "OnPointerUp" (mkFn4 \screenX screenY pointerType timeStamp -> callback screenX screenY pointerType timeStamp)

onKeyDown :: forall message. (String -> KeyboardModifiers -> message) -> Prop message
onKeyDown callback = prop \builder -> runFn3 Raw.prop1Impl builder "OnKeyDown" (mkFn2 \key modifiers -> callback key modifiers)

onKeyDownFocus :: forall message. (String -> KeyboardModifiers -> Maybe ({ focusSelector :: String, message :: message })) -> Prop message
onKeyDownFocus callback = prop \builder -> runFn3 Raw.propMaybe2Impl builder "OnKeyDownFocus" (mkFn2 \key modifiers -> callback key modifiers)

onKeyDownPreventDefault :: forall message. (String -> KeyboardModifiers -> Maybe (message)) -> Prop message
onKeyDownPreventDefault callback = prop \builder -> runFn3 Raw.propMaybe2Impl builder "OnKeyDownPreventDefault" (mkFn2 \key modifiers -> callback key modifiers)

onKeyUp :: forall message. (String -> KeyboardModifiers -> message) -> Prop message
onKeyUp callback = prop \builder -> runFn3 Raw.prop1Impl builder "OnKeyUp" (mkFn2 \key modifiers -> callback key modifiers)

onKeyUpPreventDefault :: forall message. (String -> KeyboardModifiers -> Maybe (message)) -> Prop message
onKeyUpPreventDefault callback = prop \builder -> runFn3 Raw.propMaybe2Impl builder "OnKeyUpPreventDefault" (mkFn2 \key modifiers -> callback key modifiers)

onKeyPress :: forall message. (String -> KeyboardModifiers -> message) -> Prop message
onKeyPress callback = prop \builder -> runFn3 Raw.prop1Impl builder "OnKeyPress" (mkFn2 \key modifiers -> callback key modifiers)

onFocus :: forall message. { message :: message } -> Prop message
onFocus input = prop \builder -> runFn3 Raw.prop1Impl builder "OnFocus" input.message

onBlur :: forall message. { message :: message } -> Prop message
onBlur input = prop \builder -> runFn3 Raw.prop1Impl builder "OnBlur" input.message

onInput :: forall message. (String -> message) -> Prop message
onInput callback = prop \builder -> runFn3 Raw.prop1Impl builder "OnInput" (mkFn1 \value -> callback value)

onChange :: forall message. (String -> message) -> Prop message
onChange callback = prop \builder -> runFn3 Raw.prop1Impl builder "OnChange" (mkFn1 \value -> callback value)

onFileChange :: forall message. (Array File -> message) -> Prop message
onFileChange callback = prop \builder -> runFn3 Raw.prop1Impl builder "OnFileChange" (mkFn1 \files -> callback files)

onSubmit :: forall message. { message :: message } -> Prop message
onSubmit input = prop \builder -> runFn3 Raw.prop1Impl builder "OnSubmit" input.message

onReset :: forall message. { message :: message } -> Prop message
onReset input = prop \builder -> runFn3 Raw.prop1Impl builder "OnReset" input.message

onScroll :: forall message. (Number -> message) -> Prop message
onScroll callback = prop \builder -> runFn3 Raw.prop1Impl builder "OnScroll" (mkFn1 \scrollTop -> callback scrollTop)

onWheel :: forall message. { message :: message } -> Prop message
onWheel input = prop \builder -> runFn3 Raw.prop1Impl builder "OnWheel" input.message

onCopy :: forall message. { message :: message } -> Prop message
onCopy input = prop \builder -> runFn3 Raw.prop1Impl builder "OnCopy" input.message

onCut :: forall message. { message :: message } -> Prop message
onCut input = prop \builder -> runFn3 Raw.prop1Impl builder "OnCut" input.message

onPaste :: forall message. { message :: message } -> Prop message
onPaste input = prop \builder -> runFn3 Raw.prop1Impl builder "OnPaste" input.message

onPastePreventDefault :: forall message. (String -> Maybe (message)) -> Prop message
onPastePreventDefault callback = prop \builder -> runFn3 Raw.propMaybe1Impl builder "OnPastePreventDefault" (mkFn1 \text -> callback text)

onCopyText :: forall message. String -> Prop message
onCopyText value = prop \builder -> runFn3 Raw.prop1Impl builder "OnCopyText" value

onCutText :: forall message. { text :: String, message :: message } -> Prop message
onCutText input = prop \builder -> runFn4 Raw.prop2Impl builder "OnCutText" input.text input.message

onCancel :: forall message. { message :: message } -> Prop message
onCancel input = prop \builder -> runFn3 Raw.prop1Impl builder "OnCancel" input.message

onToggle :: forall message. (Boolean -> message) -> Prop message
onToggle callback = prop \builder -> runFn3 Raw.prop1Impl builder "OnToggle" (mkFn1 \isOpen -> callback isOpen)

onContextMenu :: forall message. { message :: message } -> Prop message
onContextMenu input = prop \builder -> runFn3 Raw.prop1Impl builder "OnContextMenu" input.message

onDragStart :: forall message. { message :: message } -> Prop message
onDragStart input = prop \builder -> runFn3 Raw.prop1Impl builder "OnDragStart" input.message

onDrag :: forall message. { message :: message } -> Prop message
onDrag input = prop \builder -> runFn3 Raw.prop1Impl builder "OnDrag" input.message

onDragEnd :: forall message. { message :: message } -> Prop message
onDragEnd input = prop \builder -> runFn3 Raw.prop1Impl builder "OnDragEnd" input.message

onDragEnter :: forall message. { message :: message } -> Prop message
onDragEnter input = prop \builder -> runFn3 Raw.prop1Impl builder "OnDragEnter" input.message

onDragLeave :: forall message. { message :: message } -> Prop message
onDragLeave input = prop \builder -> runFn3 Raw.prop1Impl builder "OnDragLeave" input.message

onDragOver :: forall message. { message :: message } -> Prop message
onDragOver input = prop \builder -> runFn3 Raw.prop1Impl builder "OnDragOver" input.message

allowDrop :: forall message. Prop message
allowDrop = prop \builder -> runFn2 Raw.prop0Impl builder "AllowDrop"

onDrop :: forall message. { message :: message } -> Prop message
onDrop input = prop \builder -> runFn3 Raw.prop1Impl builder "OnDrop" input.message

onDropFiles :: forall message. (Array File -> message) -> Prop message
onDropFiles callback = prop \builder -> runFn3 Raw.prop1Impl builder "OnDropFiles" (mkFn1 \files -> callback files)

onTouchStart :: forall message. { message :: message } -> Prop message
onTouchStart input = prop \builder -> runFn3 Raw.prop1Impl builder "OnTouchStart" input.message

onTouchEnd :: forall message. { message :: message } -> Prop message
onTouchEnd input = prop \builder -> runFn3 Raw.prop1Impl builder "OnTouchEnd" input.message

onTouchMove :: forall message. { message :: message } -> Prop message
onTouchMove input = prop \builder -> runFn3 Raw.prop1Impl builder "OnTouchMove" input.message

onTouchCancel :: forall message. { message :: message } -> Prop message
onTouchCancel input = prop \builder -> runFn3 Raw.prop1Impl builder "OnTouchCancel" input.message

onAnimationStart :: forall message. { message :: message } -> Prop message
onAnimationStart input = prop \builder -> runFn3 Raw.prop1Impl builder "OnAnimationStart" input.message

onAnimationEnd :: forall message. { message :: message } -> Prop message
onAnimationEnd input = prop \builder -> runFn3 Raw.prop1Impl builder "OnAnimationEnd" input.message

onAnimationIteration :: forall message. { message :: message } -> Prop message
onAnimationIteration input = prop \builder -> runFn3 Raw.prop1Impl builder "OnAnimationIteration" input.message

onTransitionEnd :: forall message. { message :: message } -> Prop message
onTransitionEnd input = prop \builder -> runFn3 Raw.prop1Impl builder "OnTransitionEnd" input.message

onLoad :: forall message. { message :: message } -> Prop message
onLoad input = prop \builder -> runFn3 Raw.prop1Impl builder "OnLoad" input.message

onError :: forall message. { message :: message } -> Prop message
onError input = prop \builder -> runFn3 Raw.prop1Impl builder "OnError" input.message

onPlay :: forall message. { message :: message } -> Prop message
onPlay input = prop \builder -> runFn3 Raw.prop1Impl builder "OnPlay" input.message

onPause :: forall message. { message :: message } -> Prop message
onPause input = prop \builder -> runFn3 Raw.prop1Impl builder "OnPause" input.message

onEnded :: forall message. { message :: message } -> Prop message
onEnded input = prop \builder -> runFn3 Raw.prop1Impl builder "OnEnded" input.message

onTimeUpdate :: forall message. { message :: message } -> Prop message
onTimeUpdate input = prop \builder -> runFn3 Raw.prop1Impl builder "OnTimeUpdate" input.message

onVolumeChange :: forall message. { message :: message } -> Prop message
onVolumeChange input = prop \builder -> runFn3 Raw.prop1Impl builder "OnVolumeChange" input.message

onSelect :: forall message. { message :: message } -> Prop message
onSelect input = prop \builder -> runFn3 Raw.prop1Impl builder "OnSelect" input.message

value :: forall message. String -> Prop message
value value = prop \builder -> runFn3 Raw.prop1Impl builder "Value" value

checked :: forall message. Boolean -> Prop message
checked value = prop \builder -> runFn3 Raw.prop1Impl builder "Checked" value

selected :: forall message. Boolean -> Prop message
selected value = prop \builder -> runFn3 Raw.prop1Impl builder "Selected" value

open :: forall message. Boolean -> Prop message
open value = prop \builder -> runFn3 Raw.prop1Impl builder "Open" value

placeholder :: forall message. String -> Prop message
placeholder value = prop \builder -> runFn3 Raw.prop1Impl builder "Placeholder" value

name :: forall message. String -> Prop message
name value = prop \builder -> runFn3 Raw.prop1Impl builder "Name" value

disabled :: forall message. Boolean -> Prop message
disabled value = prop \builder -> runFn3 Raw.prop1Impl builder "Disabled" value

readonly :: forall message. Boolean -> Prop message
readonly value = prop \builder -> runFn3 Raw.prop1Impl builder "Readonly" value

required :: forall message. Boolean -> Prop message
required value = prop \builder -> runFn3 Raw.prop1Impl builder "Required" value

autofocus :: forall message. Boolean -> Prop message
autofocus value = prop \builder -> runFn3 Raw.prop1Impl builder "Autofocus" value

spellcheck :: forall message. Boolean -> Prop message
spellcheck value = prop \builder -> runFn3 Raw.prop1Impl builder "Spellcheck" value

autocorrect :: forall message. String -> Prop message
autocorrect value = prop \builder -> runFn3 Raw.prop1Impl builder "Autocorrect" value

autocapitalize :: forall message. String -> Prop message
autocapitalize value = prop \builder -> runFn3 Raw.prop1Impl builder "Autocapitalize" value

inputMode :: forall message. String -> Prop message
inputMode value = prop \builder -> runFn3 Raw.prop1Impl builder "InputMode" value

enterKeyHint :: forall message. String -> Prop message
enterKeyHint value = prop \builder -> runFn3 Raw.prop1Impl builder "EnterKeyHint" value

multiple :: forall message. Boolean -> Prop message
multiple value = prop \builder -> runFn3 Raw.prop1Impl builder "Multiple" value

type_ :: forall message. String -> Prop message
type_ value = prop \builder -> runFn3 Raw.prop1Impl builder "Type" value

accept :: forall message. String -> Prop message
accept value = prop \builder -> runFn3 Raw.prop1Impl builder "Accept" value

autocomplete :: forall message. String -> Prop message
autocomplete value = prop \builder -> runFn3 Raw.prop1Impl builder "Autocomplete" value

pattern :: forall message. String -> Prop message
pattern value = prop \builder -> runFn3 Raw.prop1Impl builder "Pattern" value

maxlength :: forall message. Number -> Prop message
maxlength value = prop \builder -> runFn3 Raw.prop1Impl builder "Maxlength" value

minlength :: forall message. Number -> Prop message
minlength value = prop \builder -> runFn3 Raw.prop1Impl builder "Minlength" value

size :: forall message. Number -> Prop message
size value = prop \builder -> runFn3 Raw.prop1Impl builder "Size" value

cols :: forall message. Number -> Prop message
cols value = prop \builder -> runFn3 Raw.prop1Impl builder "Cols" value

rows :: forall message. Number -> Prop message
rows value = prop \builder -> runFn3 Raw.prop1Impl builder "Rows" value

max :: forall message. String -> Prop message
max value = prop \builder -> runFn3 Raw.prop1Impl builder "Max" value

min :: forall message. String -> Prop message
min value = prop \builder -> runFn3 Raw.prop1Impl builder "Min" value

step :: forall message. String -> Prop message
step value = prop \builder -> runFn3 Raw.prop1Impl builder "Step" value

for_ :: forall message. String -> Prop message
for_ value = prop \builder -> runFn3 Raw.prop1Impl builder "For" value

href :: forall message. String -> Prop message
href value = prop \builder -> runFn3 Raw.prop1Impl builder "Href" value

src :: forall message. String -> Prop message
src value = prop \builder -> runFn3 Raw.prop1Impl builder "Src" value

alt :: forall message. String -> Prop message
alt value = prop \builder -> runFn3 Raw.prop1Impl builder "Alt" value

target :: forall message. String -> Prop message
target value = prop \builder -> runFn3 Raw.prop1Impl builder "Target" value

rel :: forall message. String -> Prop message
rel value = prop \builder -> runFn3 Raw.prop1Impl builder "Rel" value

download :: forall message. String -> Prop message
download value = prop \builder -> runFn3 Raw.prop1Impl builder "Download" value

action :: forall message. String -> Prop message
action value = prop \builder -> runFn3 Raw.prop1Impl builder "Action" value

method :: forall message. String -> Prop message
method value = prop \builder -> runFn3 Raw.prop1Impl builder "Method" value

enctype :: forall message. String -> Prop message
enctype value = prop \builder -> runFn3 Raw.prop1Impl builder "Enctype" value

novalidate :: forall message. Boolean -> Prop message
novalidate value = prop \builder -> runFn3 Raw.prop1Impl builder "Novalidate" value

formaction :: forall message. String -> Prop message
formaction value = prop \builder -> runFn3 Raw.prop1Impl builder "Formaction" value

formmethod :: forall message. String -> Prop message
formmethod value = prop \builder -> runFn3 Raw.prop1Impl builder "Formmethod" value

formnovalidate :: forall message. Boolean -> Prop message
formnovalidate value = prop \builder -> runFn3 Raw.prop1Impl builder "Formnovalidate" value

formtarget :: forall message. String -> Prop message
formtarget value = prop \builder -> runFn3 Raw.prop1Impl builder "Formtarget" value

formenctype :: forall message. String -> Prop message
formenctype value = prop \builder -> runFn3 Raw.prop1Impl builder "Formenctype" value

colspan :: forall message. Number -> Prop message
colspan value = prop \builder -> runFn3 Raw.prop1Impl builder "Colspan" value

rowspan :: forall message. Number -> Prop message
rowspan value = prop \builder -> runFn3 Raw.prop1Impl builder "Rowspan" value

scope :: forall message. String -> Prop message
scope value = prop \builder -> runFn3 Raw.prop1Impl builder "Scope" value

headers :: forall message. String -> Prop message
headers value = prop \builder -> runFn3 Raw.prop1Impl builder "Headers" value

span :: forall message. Number -> Prop message
span value = prop \builder -> runFn3 Raw.prop1Impl builder "Span" value

start :: forall message. Number -> Prop message
start value = prop \builder -> runFn3 Raw.prop1Impl builder "Start" value

reversed :: forall message. Boolean -> Prop message
reversed value = prop \builder -> runFn3 Raw.prop1Impl builder "Reversed" value

citeAttr :: forall message. String -> Prop message
citeAttr value = prop \builder -> runFn3 Raw.prop1Impl builder "CiteAttr" value

datetime :: forall message. String -> Prop message
datetime value = prop \builder -> runFn3 Raw.prop1Impl builder "Datetime" value

wrap :: forall message. String -> Prop message
wrap value = prop \builder -> runFn3 Raw.prop1Impl builder "Wrap" value

list :: forall message. String -> Prop message
list value = prop \builder -> runFn3 Raw.prop1Impl builder "List" value

formAttr :: forall message. String -> Prop message
formAttr value = prop \builder -> runFn3 Raw.prop1Impl builder "FormAttr" value

labelAttr :: forall message. String -> Prop message
labelAttr value = prop \builder -> runFn3 Raw.prop1Impl builder "LabelAttr" value

contentAttr :: forall message. String -> Prop message
contentAttr value = prop \builder -> runFn3 Raw.prop1Impl builder "ContentAttr" value

charset :: forall message. String -> Prop message
charset value = prop \builder -> runFn3 Raw.prop1Impl builder "Charset" value

httpEquiv :: forall message. String -> Prop message
httpEquiv value = prop \builder -> runFn3 Raw.prop1Impl builder "HttpEquiv" value

srcset :: forall message. String -> Prop message
srcset value = prop \builder -> runFn3 Raw.prop1Impl builder "Srcset" value

sizes :: forall message. String -> Prop message
sizes value = prop \builder -> runFn3 Raw.prop1Impl builder "Sizes" value

loading :: forall message. String -> Prop message
loading value = prop \builder -> runFn3 Raw.prop1Impl builder "Loading" value

decoding :: forall message. String -> Prop message
decoding value = prop \builder -> runFn3 Raw.prop1Impl builder "Decoding" value

fetchpriority :: forall message. String -> Prop message
fetchpriority value = prop \builder -> runFn3 Raw.prop1Impl builder "Fetchpriority" value

crossorigin :: forall message. String -> Prop message
crossorigin value = prop \builder -> runFn3 Raw.prop1Impl builder "Crossorigin" value

referrerpolicy :: forall message. String -> Prop message
referrerpolicy value = prop \builder -> runFn3 Raw.prop1Impl builder "Referrerpolicy" value

integrity :: forall message. String -> Prop message
integrity value = prop \builder -> runFn3 Raw.prop1Impl builder "Integrity" value

hreflang :: forall message. String -> Prop message
hreflang value = prop \builder -> runFn3 Raw.prop1Impl builder "Hreflang" value

ping :: forall message. String -> Prop message
ping value = prop \builder -> runFn3 Raw.prop1Impl builder "Ping" value

sandbox :: forall message. String -> Prop message
sandbox value = prop \builder -> runFn3 Raw.prop1Impl builder "Sandbox" value

allow :: forall message. String -> Prop message
allow value = prop \builder -> runFn3 Raw.prop1Impl builder "Allow" value

srcdoc :: forall message. String -> Prop message
srcdoc value = prop \builder -> runFn3 Raw.prop1Impl builder "Srcdoc" value

autoplay :: forall message. Boolean -> Prop message
autoplay value = prop \builder -> runFn3 Raw.prop1Impl builder "Autoplay" value

controls :: forall message. Boolean -> Prop message
controls value = prop \builder -> runFn3 Raw.prop1Impl builder "Controls" value

loop :: forall message. Boolean -> Prop message
loop value = prop \builder -> runFn3 Raw.prop1Impl builder "Loop" value

muted :: forall message. Boolean -> Prop message
muted value = prop \builder -> runFn3 Raw.prop1Impl builder "Muted" value

poster :: forall message. String -> Prop message
poster value = prop \builder -> runFn3 Raw.prop1Impl builder "Poster" value

preload :: forall message. String -> Prop message
preload value = prop \builder -> runFn3 Raw.prop1Impl builder "Preload" value

playsinline :: forall message. Boolean -> Prop message
playsinline value = prop \builder -> runFn3 Raw.prop1Impl builder "Playsinline" value

high :: forall message. Number -> Prop message
high value = prop \builder -> runFn3 Raw.prop1Impl builder "High" value

low :: forall message. Number -> Prop message
low value = prop \builder -> runFn3 Raw.prop1Impl builder "Low" value

optimum :: forall message. Number -> Prop message
optimum value = prop \builder -> runFn3 Raw.prop1Impl builder "Optimum" value

usemap :: forall message. String -> Prop message
usemap value = prop \builder -> runFn3 Raw.prop1Impl builder "Usemap" value

ismap :: forall message. Boolean -> Prop message
ismap value = prop \builder -> runFn3 Raw.prop1Impl builder "Ismap" value

role_ :: forall message. String -> Prop message
role_ value = prop \builder -> runFn3 Raw.prop1Impl builder "Role" value

ariaLabel :: forall message. String -> Prop message
ariaLabel value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaLabel" value

ariaLabelledBy :: forall message. String -> Prop message
ariaLabelledBy value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaLabelledBy" value

ariaDescribedBy :: forall message. String -> Prop message
ariaDescribedBy value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaDescribedBy" value

ariaHidden :: forall message. Boolean -> Prop message
ariaHidden value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaHidden" value

ariaExpanded :: forall message. Boolean -> Prop message
ariaExpanded value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaExpanded" value

ariaSelected :: forall message. Boolean -> Prop message
ariaSelected value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaSelected" value

ariaChecked :: forall message. AriaChecked -> Prop message
ariaChecked value = prop \builder -> runFn3 Raw.propAriaCheckedImpl builder "AriaChecked" value

ariaDisabled :: forall message. Boolean -> Prop message
ariaDisabled value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaDisabled" value

ariaRequired :: forall message. Boolean -> Prop message
ariaRequired value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaRequired" value

ariaInvalid :: forall message. Boolean -> Prop message
ariaInvalid value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaInvalid" value

ariaLive :: forall message. String -> Prop message
ariaLive value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaLive" value

ariaControls :: forall message. String -> Prop message
ariaControls value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaControls" value

ariaCurrent :: forall message. String -> Prop message
ariaCurrent value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaCurrent" value

ariaOrientation :: forall message. String -> Prop message
ariaOrientation value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaOrientation" value

ariaPressed :: forall message. String -> Prop message
ariaPressed value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaPressed" value

ariaHasPopup :: forall message. String -> Prop message
ariaHasPopup value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaHasPopup" value

ariaActiveDescendant :: forall message. String -> Prop message
ariaActiveDescendant value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaActiveDescendant" value

ariaSort :: forall message. String -> Prop message
ariaSort value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaSort" value

ariaMultiSelectable :: forall message. Boolean -> Prop message
ariaMultiSelectable value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaMultiSelectable" value

ariaModal :: forall message. Boolean -> Prop message
ariaModal value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaModal" value

ariaBusy :: forall message. Boolean -> Prop message
ariaBusy value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaBusy" value

ariaErrorMessage :: forall message. String -> Prop message
ariaErrorMessage value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaErrorMessage" value

ariaRoleDescription :: forall message. String -> Prop message
ariaRoleDescription value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaRoleDescription" value

ariaAtomic :: forall message. Boolean -> Prop message
ariaAtomic value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaAtomic" value

ariaAutocomplete :: forall message. String -> Prop message
ariaAutocomplete value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaAutocomplete" value

ariaColcount :: forall message. Number -> Prop message
ariaColcount value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaColcount" value

ariaColindex :: forall message. Number -> Prop message
ariaColindex value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaColindex" value

ariaColspan :: forall message. Number -> Prop message
ariaColspan value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaColspan" value

ariaDescription :: forall message. String -> Prop message
ariaDescription value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaDescription" value

ariaDetails :: forall message. String -> Prop message
ariaDetails value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaDetails" value

ariaFlowto :: forall message. String -> Prop message
ariaFlowto value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaFlowto" value

ariaKeyshortcuts :: forall message. String -> Prop message
ariaKeyshortcuts value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaKeyshortcuts" value

ariaLevel :: forall message. Number -> Prop message
ariaLevel value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaLevel" value

ariaOwns :: forall message. String -> Prop message
ariaOwns value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaOwns" value

ariaPlaceholder :: forall message. String -> Prop message
ariaPlaceholder value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaPlaceholder" value

ariaPosinset :: forall message. Number -> Prop message
ariaPosinset value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaPosinset" value

ariaReadonly :: forall message. Boolean -> Prop message
ariaReadonly value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaReadonly" value

ariaRelevant :: forall message. String -> Prop message
ariaRelevant value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaRelevant" value

ariaRowcount :: forall message. Number -> Prop message
ariaRowcount value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaRowcount" value

ariaRowindex :: forall message. Number -> Prop message
ariaRowindex value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaRowindex" value

ariaRowspan :: forall message. Number -> Prop message
ariaRowspan value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaRowspan" value

ariaSetsize :: forall message. Number -> Prop message
ariaSetsize value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaSetsize" value

ariaValuemax :: forall message. Number -> Prop message
ariaValuemax value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaValuemax" value

ariaValuemin :: forall message. Number -> Prop message
ariaValuemin value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaValuemin" value

ariaValuenow :: forall message. Number -> Prop message
ariaValuenow value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaValuenow" value

ariaValuetext :: forall message. String -> Prop message
ariaValuetext value = prop \builder -> runFn3 Raw.prop1Impl builder "AriaValuetext" value

attribute :: forall message. String -> String -> Prop message
attribute left right = prop \builder -> runFn4 Raw.prop2Impl builder "Attribute" left right

dataAttribute :: forall message. String -> String -> Prop message
dataAttribute left right = prop \builder -> runFn4 Raw.prop2Impl builder "DataAttribute" left right

style :: forall row message. { | row } -> Prop message
style value = prop \builder -> runFn3 Raw.prop1Impl builder "Style" value

innerHtml :: forall message. String -> Prop message
innerHtml value = prop \builder -> runFn3 Raw.prop1Impl builder "InnerHTML" value

viewBox :: forall message. String -> Prop message
viewBox value = prop \builder -> runFn3 Raw.prop1Impl builder "ViewBox" value

xmlns :: forall message. String -> Prop message
xmlns value = prop \builder -> runFn3 Raw.prop1Impl builder "Xmlns" value

fill :: forall message. String -> Prop message
fill value = prop \builder -> runFn3 Raw.prop1Impl builder "Fill" value

fillRule :: forall message. String -> Prop message
fillRule value = prop \builder -> runFn3 Raw.prop1Impl builder "FillRule" value

clipRule :: forall message. String -> Prop message
clipRule value = prop \builder -> runFn3 Raw.prop1Impl builder "ClipRule" value

stroke :: forall message. String -> Prop message
stroke value = prop \builder -> runFn3 Raw.prop1Impl builder "Stroke" value

strokeWidth :: forall message. String -> Prop message
strokeWidth value = prop \builder -> runFn3 Raw.prop1Impl builder "StrokeWidth" value

strokeLinecap :: forall message. String -> Prop message
strokeLinecap value = prop \builder -> runFn3 Raw.prop1Impl builder "StrokeLinecap" value

strokeLinejoin :: forall message. String -> Prop message
strokeLinejoin value = prop \builder -> runFn3 Raw.prop1Impl builder "StrokeLinejoin" value

d :: forall message. String -> Prop message
d value = prop \builder -> runFn3 Raw.prop1Impl builder "D" value

cx :: forall message. String -> Prop message
cx value = prop \builder -> runFn3 Raw.prop1Impl builder "Cx" value

cy :: forall message. String -> Prop message
cy value = prop \builder -> runFn3 Raw.prop1Impl builder "Cy" value

r :: forall message. String -> Prop message
r value = prop \builder -> runFn3 Raw.prop1Impl builder "R" value

x :: forall message. String -> Prop message
x value = prop \builder -> runFn3 Raw.prop1Impl builder "X" value

y :: forall message. String -> Prop message
y value = prop \builder -> runFn3 Raw.prop1Impl builder "Y" value

width :: forall message. String -> Prop message
width value = prop \builder -> runFn3 Raw.prop1Impl builder "Width" value

height :: forall message. String -> Prop message
height value = prop \builder -> runFn3 Raw.prop1Impl builder "Height" value

x1 :: forall message. String -> Prop message
x1 value = prop \builder -> runFn3 Raw.prop1Impl builder "X1" value

y1 :: forall message. String -> Prop message
y1 value = prop \builder -> runFn3 Raw.prop1Impl builder "Y1" value

x2 :: forall message. String -> Prop message
x2 value = prop \builder -> runFn3 Raw.prop1Impl builder "X2" value

y2 :: forall message. String -> Prop message
y2 value = prop \builder -> runFn3 Raw.prop1Impl builder "Y2" value

points :: forall message. String -> Prop message
points value = prop \builder -> runFn3 Raw.prop1Impl builder "Points" value

transform :: forall message. String -> Prop message
transform value = prop \builder -> runFn3 Raw.prop1Impl builder "Transform" value

opacity :: forall message. String -> Prop message
opacity value = prop \builder -> runFn3 Raw.prop1Impl builder "Opacity" value

strokeDasharray :: forall message. String -> Prop message
strokeDasharray value = prop \builder -> runFn3 Raw.prop1Impl builder "StrokeDasharray" value

strokeDashoffset :: forall message. String -> Prop message
strokeDashoffset value = prop \builder -> runFn3 Raw.prop1Impl builder "StrokeDashoffset" value

dx :: forall message. String -> Prop message
dx value = prop \builder -> runFn3 Raw.prop1Impl builder "Dx" value

dy :: forall message. String -> Prop message
dy value = prop \builder -> runFn3 Raw.prop1Impl builder "Dy" value

rotate :: forall message. String -> Prop message
rotate value = prop \builder -> runFn3 Raw.prop1Impl builder "Rotate" value

textAnchor :: forall message. String -> Prop message
textAnchor value = prop \builder -> runFn3 Raw.prop1Impl builder "TextAnchor" value

dominantBaseline :: forall message. String -> Prop message
dominantBaseline value = prop \builder -> runFn3 Raw.prop1Impl builder "DominantBaseline" value

alignmentBaseline :: forall message. String -> Prop message
alignmentBaseline value = prop \builder -> runFn3 Raw.prop1Impl builder "AlignmentBaseline" value

baselineShift :: forall message. String -> Prop message
baselineShift value = prop \builder -> runFn3 Raw.prop1Impl builder "BaselineShift" value

textLength :: forall message. String -> Prop message
textLength value = prop \builder -> runFn3 Raw.prop1Impl builder "TextLength" value

lengthAdjust :: forall message. String -> Prop message
lengthAdjust value = prop \builder -> runFn3 Raw.prop1Impl builder "LengthAdjust" value

fontFamily :: forall message. String -> Prop message
fontFamily value = prop \builder -> runFn3 Raw.prop1Impl builder "FontFamily" value

fontSize :: forall message. String -> Prop message
fontSize value = prop \builder -> runFn3 Raw.prop1Impl builder "FontSize" value

fontWeight :: forall message. String -> Prop message
fontWeight value = prop \builder -> runFn3 Raw.prop1Impl builder "FontWeight" value

fontStyle :: forall message. String -> Prop message
fontStyle value = prop \builder -> runFn3 Raw.prop1Impl builder "FontStyle" value

letterSpacing :: forall message. String -> Prop message
letterSpacing value = prop \builder -> runFn3 Raw.prop1Impl builder "LetterSpacing" value

wordSpacing :: forall message. String -> Prop message
wordSpacing value = prop \builder -> runFn3 Raw.prop1Impl builder "WordSpacing" value

textDecoration :: forall message. String -> Prop message
textDecoration value = prop \builder -> runFn3 Raw.prop1Impl builder "TextDecoration" value

writingMode :: forall message. String -> Prop message
writingMode value = prop \builder -> runFn3 Raw.prop1Impl builder "WritingMode" value

rx :: forall message. String -> Prop message
rx value = prop \builder -> runFn3 Raw.prop1Impl builder "Rx" value

ry :: forall message. String -> Prop message
ry value = prop \builder -> runFn3 Raw.prop1Impl builder "Ry" value

pathLength :: forall message. String -> Prop message
pathLength value = prop \builder -> runFn3 Raw.prop1Impl builder "PathLength" value

fillOpacity :: forall message. String -> Prop message
fillOpacity value = prop \builder -> runFn3 Raw.prop1Impl builder "FillOpacity" value

strokeOpacity :: forall message. String -> Prop message
strokeOpacity value = prop \builder -> runFn3 Raw.prop1Impl builder "StrokeOpacity" value

strokeMiterlimit :: forall message. String -> Prop message
strokeMiterlimit value = prop \builder -> runFn3 Raw.prop1Impl builder "StrokeMiterlimit" value

paintOrder :: forall message. String -> Prop message
paintOrder value = prop \builder -> runFn3 Raw.prop1Impl builder "PaintOrder" value

vectorEffect :: forall message. String -> Prop message
vectorEffect value = prop \builder -> runFn3 Raw.prop1Impl builder "VectorEffect" value

color :: forall message. String -> Prop message
color value = prop \builder -> runFn3 Raw.prop1Impl builder "Color" value

visibility :: forall message. String -> Prop message
visibility value = prop \builder -> runFn3 Raw.prop1Impl builder "Visibility" value

display :: forall message. String -> Prop message
display value = prop \builder -> runFn3 Raw.prop1Impl builder "Display" value

overflow :: forall message. String -> Prop message
overflow value = prop \builder -> runFn3 Raw.prop1Impl builder "Overflow" value

pointerEvents :: forall message. String -> Prop message
pointerEvents value = prop \builder -> runFn3 Raw.prop1Impl builder "PointerEvents" value

cursor :: forall message. String -> Prop message
cursor value = prop \builder -> runFn3 Raw.prop1Impl builder "Cursor" value

shapeRendering :: forall message. String -> Prop message
shapeRendering value = prop \builder -> runFn3 Raw.prop1Impl builder "ShapeRendering" value

textRendering :: forall message. String -> Prop message
textRendering value = prop \builder -> runFn3 Raw.prop1Impl builder "TextRendering" value

imageRendering :: forall message. String -> Prop message
imageRendering value = prop \builder -> runFn3 Raw.prop1Impl builder "ImageRendering" value

clipPath :: forall message. String -> Prop message
clipPath value = prop \builder -> runFn3 Raw.prop1Impl builder "ClipPath" value

mask :: forall message. String -> Prop message
mask value = prop \builder -> runFn3 Raw.prop1Impl builder "Mask" value

filter :: forall message. String -> Prop message
filter value = prop \builder -> runFn3 Raw.prop1Impl builder "Filter" value

clipPathUnits :: forall message. String -> Prop message
clipPathUnits value = prop \builder -> runFn3 Raw.prop1Impl builder "ClipPathUnits" value

maskUnits :: forall message. String -> Prop message
maskUnits value = prop \builder -> runFn3 Raw.prop1Impl builder "MaskUnits" value

maskContentUnits :: forall message. String -> Prop message
maskContentUnits value = prop \builder -> runFn3 Raw.prop1Impl builder "MaskContentUnits" value

filterUnits :: forall message. String -> Prop message
filterUnits value = prop \builder -> runFn3 Raw.prop1Impl builder "FilterUnits" value

primitiveUnits :: forall message. String -> Prop message
primitiveUnits value = prop \builder -> runFn3 Raw.prop1Impl builder "PrimitiveUnits" value

offset :: forall message. String -> Prop message
offset value = prop \builder -> runFn3 Raw.prop1Impl builder "Offset" value

stopColor :: forall message. String -> Prop message
stopColor value = prop \builder -> runFn3 Raw.prop1Impl builder "StopColor" value

stopOpacity :: forall message. String -> Prop message
stopOpacity value = prop \builder -> runFn3 Raw.prop1Impl builder "StopOpacity" value

gradientUnits :: forall message. String -> Prop message
gradientUnits value = prop \builder -> runFn3 Raw.prop1Impl builder "GradientUnits" value

gradientTransform :: forall message. String -> Prop message
gradientTransform value = prop \builder -> runFn3 Raw.prop1Impl builder "GradientTransform" value

spreadMethod :: forall message. String -> Prop message
spreadMethod value = prop \builder -> runFn3 Raw.prop1Impl builder "SpreadMethod" value

fx :: forall message. String -> Prop message
fx value = prop \builder -> runFn3 Raw.prop1Impl builder "Fx" value

fy :: forall message. String -> Prop message
fy value = prop \builder -> runFn3 Raw.prop1Impl builder "Fy" value

fr :: forall message. String -> Prop message
fr value = prop \builder -> runFn3 Raw.prop1Impl builder "Fr" value

patternUnits :: forall message. String -> Prop message
patternUnits value = prop \builder -> runFn3 Raw.prop1Impl builder "PatternUnits" value

patternContentUnits :: forall message. String -> Prop message
patternContentUnits value = prop \builder -> runFn3 Raw.prop1Impl builder "PatternContentUnits" value

patternTransform :: forall message. String -> Prop message
patternTransform value = prop \builder -> runFn3 Raw.prop1Impl builder "PatternTransform" value

markerStart :: forall message. String -> Prop message
markerStart value = prop \builder -> runFn3 Raw.prop1Impl builder "MarkerStart" value

markerMid :: forall message. String -> Prop message
markerMid value = prop \builder -> runFn3 Raw.prop1Impl builder "MarkerMid" value

markerEnd :: forall message. String -> Prop message
markerEnd value = prop \builder -> runFn3 Raw.prop1Impl builder "MarkerEnd" value

markerWidth :: forall message. String -> Prop message
markerWidth value = prop \builder -> runFn3 Raw.prop1Impl builder "MarkerWidth" value

markerHeight :: forall message. String -> Prop message
markerHeight value = prop \builder -> runFn3 Raw.prop1Impl builder "MarkerHeight" value

markerUnits :: forall message. String -> Prop message
markerUnits value = prop \builder -> runFn3 Raw.prop1Impl builder "MarkerUnits" value

refX :: forall message. String -> Prop message
refX value = prop \builder -> runFn3 Raw.prop1Impl builder "RefX" value

refY :: forall message. String -> Prop message
refY value = prop \builder -> runFn3 Raw.prop1Impl builder "RefY" value

orient :: forall message. String -> Prop message
orient value = prop \builder -> runFn3 Raw.prop1Impl builder "Orient" value

preserveAspectRatio :: forall message. String -> Prop message
preserveAspectRatio value = prop \builder -> runFn3 Raw.prop1Impl builder "PreserveAspectRatio" value

onMount :: forall message. { action :: MountAction message } -> Prop message
onMount input = prop \builder -> runFn3 Raw.prop1Impl builder "OnMount" input.action

onUnmount :: forall message. { message :: message } -> Prop message
onUnmount input = prop \builder -> runFn3 Raw.prop1Impl builder "OnUnmount" input.message

attr :: forall message. String -> String -> Prop message
attr = attribute
