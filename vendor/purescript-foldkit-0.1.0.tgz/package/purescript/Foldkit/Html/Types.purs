module Foldkit.Html.Types
  ( HtmlBuilder
  , Html
  , RenderedProp
  , RenderedChild
  , Prop(..)
  , Child(..)
  , prop
  , child
  , renderProp
  , renderChild
  , render
  ) where

import Data.Function.Uncurried (runFn1)
import Foldkit.Raw.Html as Raw

type HtmlBuilder message = Raw.HtmlBuilder message

type Html message = Raw.Html message

type RenderedProp message = Raw.RenderedProp message

type RenderedChild message = Raw.RenderedChild message

newtype Prop message = Prop (HtmlBuilder message -> RenderedProp message)

newtype Child message = Child (HtmlBuilder message -> RenderedChild message)

prop :: forall message. (HtmlBuilder message -> RenderedProp message) -> Prop message
prop = Prop

child :: forall message. (HtmlBuilder message -> RenderedChild message) -> Child message
child = Child

renderProp :: forall message. HtmlBuilder message -> Prop message -> RenderedProp message
renderProp builder (Prop renderer) = renderer builder

renderChild :: forall message. HtmlBuilder message -> Child message -> RenderedChild message
renderChild builder (Child renderer) = renderer builder

render :: forall message. HtmlBuilder message -> Child message -> Html message
render builder value = runFn1 Raw.rootImpl (renderChild builder value)
