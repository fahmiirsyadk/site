# purescript-foldkit

Local pre-release PureScript bindings for Foldkit 0.151.0. The package is
consumed automatically by `purs-ts` through generated package metadata;
applications do not configure backend arguments, module mappings, source
globs, roots, a runtime profile, or an entry runner.

## Public API

The normal application namespace is:

- `Foldkit.Html` and `Foldkit.Html.Prop`: typed renderer-newtype HTML DSL;
- `Foldkit.Document`: minimal document construction plus typed metadata
  modifiers;
- `Foldkit.Command`: lazy, named, error-free commands backed by native
  `PursTs.Effect` values;
- `Foldkit.Mount`: scoped resource actions whose lifetime follows the element;
- `Foldkit.Submodel`: builder-free child views and message mapping;
- `Foldkit.Update`: pure update construction and child folding;
- `Foldkit.Runtime`: normalized URLs, direct application messages, and runtime
  startup.

`Foldkit.Raw.*` contains the lower provider boundary for advanced binding work.
It is not the normal application API. Applications do not need a handwritten
runtime bridge, command wire format, message decoder, HTML element inventory,
`HtmlBuilder`, or Effect thunk adapter.

The complete HTML/SVG/MathML element inventory, all 307 Foldkit properties, and
`purs-ts.bindings.json` are generated from the pinned Foldkit declaration files
by:

```bash
npm --prefix purescript-foldkit run generate
```

Generation records the exact Foldkit version and SHA-256 of every consumed
declaration. `purs-ts build` rejects a missing, repacked, modified, or different
Foldkit installation; there is no compatibility fallback. Property generation
uses a fixed mapping for primitives, messages, `Maybe` callbacks, keyboard
modifiers, files, mount actions, styles, and `aria-checked`. A new declaration
shape fails generation until its representation is deliberately added.
Keyword and normalization conflicts use an explicit rename table (`class_`,
`for_`, `role_`, `type_`, and `innerHtml`). The generated sidecar's
`generatedExports` maps all 212 element and 307 property PureScript names back
to their original Foldkit exports; unresolved collisions fail generation.

## Consumer setup

Install the two local archives and the exact peer versions:

```bash
pnpm add -D ./vendor/purs-backend-ts-0.1.0.tgz
pnpm add ./vendor/purescript-foldkit-0.1.0.tgz \
  foldkit@0.151.0 effect@4.0.0-rc.111
pnpm exec purs-ts build
pnpm exec purs-ts dev
```

Keep `spago.yaml` limited to ordinary PureScript packages and dependencies.
The binding package supplies its PureScript sources, direct TypeScript
providers, Effect/tagged-record requirements, declaration hashes, and
`effectSync` entry runner through its generated sidecar.

An application entry is a native Effect:

```purescript
import Foldkit.Runtime as Runtime
import PursTs.Effect as Fx

main :: Fx.Effect Fx.Never Fx.NoServices Unit
main = Runtime.run
  { init
  , update
  , view
  , onUrlRequest
  , onUrlChange
  }
```

Commands convert expected failures to application messages. Mount acquisition
uses `Fx.Scope`, allowing Foldkit to keep the resource alive until unmount and
then run its release Effect.

## Distribution

From the backend repository root:

```bash
npm run release:purs-ts-tarball
```

This writes checksummed backend and binding archives under `release/` and
clean-installs the exact backend archive in an isolated consumer. Copy the
archives and `.sha256` files into a consumer's `vendor/` directory, verify the
checksums, install, then run that consumer's normal gates.
