module PursTs.Effect
  ( Effect
  , Never
  , NoServices
  , Scope
  , succeed
  , fail
  , sync
  , suspend
  , map
  , flatMap
  , as
  , mapError
  , catchAll
  , match
  , acquireRelease
  , sleepMilliseconds
  , zip
  , zipPar
  ) where

import Prelude hiding (map)

foreign import data Effect :: Type -> Type -> Type -> Type
foreign import data Never :: Type
foreign import data NoServices :: Type
foreign import data Scope :: Type

foreign import succeed :: forall error requirements value. value -> Effect error requirements value
foreign import fail :: forall error requirements value. error -> Effect error requirements value
foreign import sync :: forall value. (Unit -> value) -> Effect Never NoServices value
foreign import suspend :: forall error requirements value. (Unit -> Effect error requirements value) -> Effect error requirements value
foreign import map :: forall error requirements value result. Effect error requirements value -> (value -> result) -> Effect error requirements result
foreign import flatMap :: forall error requirements value result. Effect error requirements value -> (value -> Effect error requirements result) -> Effect error requirements result
foreign import as :: forall error requirements value result. result -> Effect error requirements value -> Effect error requirements result
foreign import mapError :: forall error1 error2 requirements value. Effect error1 requirements value -> (error1 -> error2) -> Effect error2 requirements value
foreign import catchAll :: forall error requirements value. Effect error requirements value -> (error -> Effect Never requirements value) -> Effect Never requirements value
foreign import match :: forall error requirements value result. Effect error requirements value -> { onFailure :: error -> result, onSuccess :: value -> result } -> Effect Never requirements result
foreign import acquireRelease :: forall error value. Effect error NoServices value -> (value -> Effect Never NoServices Unit) -> Effect error Scope value
foreign import sleepMilliseconds :: Int -> Effect Never NoServices Unit
foreign import zip :: forall error requirements left right. Effect error requirements left -> Effect error requirements right -> Effect error requirements { first :: left, second :: right }
foreign import zipPar :: forall error requirements left right. Effect error requirements left -> Effect error requirements right -> Effect error requirements { first :: left, second :: right }

instance functorEffect :: Functor (Effect error requirements) where
  map mapper effect = map effect mapper

instance applyEffect :: Apply (Effect error requirements) where
  apply functionEffect valueEffect = flatMap functionEffect \mapper -> map valueEffect mapper

instance applicativeEffect :: Applicative (Effect error requirements) where
  pure = succeed

instance bindEffect :: Bind (Effect error requirements) where
  bind = flatMap

instance monadEffect :: Monad (Effect error requirements)
