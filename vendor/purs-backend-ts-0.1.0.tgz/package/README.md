# purs-backend-ts

`purs-backend-ts` is a PureScript alternate backend that reads compiler CoreFn
and emits TypeScript modules directly. The package contains one self-contained
`purs-ts` executable; it does not need this repository's generated `output/`
tree at runtime.

```bash
npm install --save-dev ./purs-backend-ts-0.1.0.tgz
npx purs-ts build \
  --runtime effect \
  --adt-runtime constructor \
  --corefn-dir output \
  --output-dir output \
  --module App.Entry
```

Repeat `--module` for every module that the host imports directly or treats as
a public runtime root. See the repository
[`docs/purs-ts-consumer-handoff.md`](https://github.com/aristanetworks/purescript-backend-optimizer/blob/main/docs/purs-ts-consumer-handoff.md) for
Spago configuration, TypeScript host settings, FFI rules, compatibility, and
release gates.

For backend development, compile the PureScript CLI and run it from the
checkout:

```bash
npm exec spago build -p backend-ts
node backend-ts/index.js --help
node backend-ts/index.js build --corefn-dir output --output-dir output-ts --module Main
```

The CLI writes a `.purs-ts-manifest` in the output root. Re-running a build
preserves unchanged generated files and removes stale files recorded by the
previous run. Stage 22 also keeps generated module text under
`.purs-ts-cache/`, keyed by CoreFn/docs, imported type sidecars, profiles,
root pruning, and FFI contents. `.purs-ts-graph` records runtime, type-only,
and re-export edges with each module's cache key. The CoreFn load and backend
analysis pass still runs on each build; the cache skips repeated TypeScript
lowering, declaration rendering, provider rewriting, and output writes.

TypeScript FFI siblings (`Module.purs` + `Module.ts`) are preferred. Every
foreign import must be a named provider export; diagnostics include the module,
binding, and expected curried/uncurried arity when an export is missing. Relative
provider imports are rewritten from the source provider directory to the
generated `foreign.ts` path. Legacy `.js` siblings remain a compatibility path
and are copied with `@ts-nocheck`.

For a consumer Vite project, run its PureScript build before the dev server,
for example `npm run build:ps && npm run dev -- --host 0.0.0.0`. The focused
Stage 21 manifest/FFI regression is `npm run test:stage21-ts`; Stage 22 cache
and graph behavior is covered by `npm run test:stage22-ts`; Stage 23 type and
output coverage is covered by `npm run test:stage23-ts`. The Stage 23 fixtures
exercise general `FnN` signatures, open-row records, and opaque foreign data.

This package is pre-release software. Version `0.1.x` documents the tested
compatibility surface; it does not yet promise support for every CoreFn shape.
