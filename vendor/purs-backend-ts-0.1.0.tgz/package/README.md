# purs-backend-ts

`purs-backend-ts` is a PureScript alternate backend that reads compiler CoreFn
and emits TypeScript modules directly. The package contains one self-contained
`purs-ts` executable; it does not need this repository's generated `output/`
tree at runtime.

```bash
npm install --save-dev ./purs-backend-ts-0.1.0.tgz
npx purs-ts build \
  --runtime effect \
  --adt-runtime constructor \
  --corefn-dir output \
  --output-dir output \
  --module App.Entry
```

Repeat `--module` for every module that the host imports directly or treats as
a public runtime root. See the repository
[`docs/purs-ts-consumer-handoff.md`](https://github.com/aristanetworks/purescript-backend-optimizer/blob/main/docs/purs-ts-consumer-handoff.md) for
Spago configuration, TypeScript host settings, FFI rules, compatibility, and
release gates.

This package is pre-release software. Version `0.1.x` documents the tested
compatibility surface; it does not yet promise support for every CoreFn shape.
