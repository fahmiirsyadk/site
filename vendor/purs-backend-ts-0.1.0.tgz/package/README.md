# purs-backend-ts

`purs-backend-ts` is an experimental PureScript alternate backend. It consumes
the PureScript compiler's CoreFn and `docs.json` products and emits TypeScript
modules, declarations, runtime facades, and FFI providers.

It is not a source-to-source TypeScript translator and does not replace the
PureScript compiler:

```text
.purs → purs (typecheck, desugar, CoreFn, docs.json)
      → purs-backend-ts (analyze, lower, prune, print)
      → .ts / .d.ts / foreign.ts
      → tsc / bundler / runtime
```

The implementation is pre-release. Support is defined by the fixtures under
[`src/Mvp`](./src/Mvp) and [`test`](./test), not by all possible CoreFn shapes
or FFI conventions.

## Purpose

The normal PureScript JavaScript backend erases the source type boundary for a
TypeScript consumer. A separate declaration bridge then has to duplicate ADTs,
records, function signatures, and entry-point adapters.

This backend makes the generated TypeScript boundary compiler-owned:

- CoreFn is the value-level semantic input;
- `docs.json` supplies public type information;
- PureScript remains the source of behavior and types;
- TypeScript owns host APIs and external-library providers;
- strict TypeScript validation runs against the generated tree.

## Technical comparison

| Concern | `purs` JavaScript backend | JavaScript + declaration bridge | `purs-backend-ts` |
| --- | --- | --- | --- |
| Backend input | CoreFn | CoreFn | CoreFn + `docs.json` |
| Output | `.js` | `.js` + handwritten/generated bridge | `.ts`, `.d.ts`, `foreign.ts` |
| Consumer types | Reconstructed outside backend | Can drift from PureScript | Reconstructed during backend generation |
| ADTs | JavaScript values | Runtime and bridge may diverge | Typed generated tagged/constructor values |
| FFI | Usually `.js` | Bridge adapters | `.ts` preferred; `.js` compatibility fallback |
| Validation | PureScript/JavaScript checks | Bridge TypeScript checks | Generated-tree `tsc --noEmit` |
| Unused code | JavaScript optimizer | Backend and bridge | Source warnings + generated liveness |
| Entry/root setup | JavaScript entry conventions | Extra roots and entry glue | `purs-ts` discovery and generated entry |

## Consumer configuration

### `package.json`

The backend is used as a build tool, not as a PureScript package dependency:

```json
{
  "type": "module",
  "scripts": {
    "build": "purs-ts build",
    "dev": "purs-ts dev"
  },
  "devDependencies": {
    "purs-backend-ts": "file:vendor/purs-backend-ts-0.1.0.tgz",
    "purescript": "0.15.16",
    "spago": "1.0.4",
    "typescript": "^6.0.3"
  }
}
```

The local tarball path is illustrative. The package is not published to npm
yet.

### `spago.yaml`

Use ordinary PureScript dependencies. Do not configure an alternate backend,
backend arguments, output paths, or a roots manifest:

```yaml
package:
  name: example-app
  dependencies:
    - effect: ">=4.0.0 <5.0.0"
    - prelude: ">=6.0.2 <7.0.0"

workspace:
  extraPackages: {}
```

`purs-ts` obtains source globs from Spago, compiles CoreFn/docs, discovers a
project `main ::` module, and discovers additional PureScript modules imported
by TypeScript host files. Consumers do not pass repeated `--module` options.

### `tsconfig.json`

The generated output is checked with the consumer's TypeScript configuration:

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "strict": true,
    "noEmit": true,
    "allowImportingTsExtensions": true
  },
  "include": ["src", "output"]
}
```

### Commands

```bash
pnpm install
pnpm exec purs-ts build
pnpm exec purs-ts dev
```

`build` writes a staged generated tree, validates it with `tsc --noEmit`, and
promotes it to `output/` only after validation succeeds. `dev` rebuilds when a
`.purs` file or a TypeScript FFI sibling changes.

## PureScript to TypeScript

The examples below show the emitted representation. Internal names and
formatting may change; the public type and calling shape are the contract.

### ADTs and pattern matching

PureScript:

```purescript
data Shape
  = Circle Int
  | Empty

describe :: Shape -> String
describe = case _ of
  Circle _ -> "circle"
  Empty -> "empty"
```

Representative output:

```typescript
export type Shape =
  | { "tag": "Circle"; "_1": number }
  | { "tag": "Empty" };

const describe$internal = (value: Shape): string =>
  value.tag === "Circle"
    ? "circle"
    : value.tag === "Empty"
      ? "empty"
      : $runtime.fail();

export const describe = (arg0: Shape): string => describe$internal(arg0);
```

### Records and functions

PureScript:

```purescript
type User = { name :: String, age :: Int }

makeUser :: String -> Int -> User
makeUser name age = { name, age }
```

Representative output:

```typescript
export type User = { "name": string; "age": number };

const makeUser$internal = (name: string) => (age: number): User => ({
  "name": name,
  "age": age,
});

export const makeUser = (arg0: string) => (arg1: number): User =>
  makeUser$internal(arg0)(arg1);
```

PureScript application remains curried. A foreign function with multiple
arguments receives a generated uncurried TypeScript provider adapter while
same-module PureScript calls retain the curried internal form.

### Newtypes and primitive types

Newtypes erase to their underlying runtime value. Common mappings include:

```text
Unit       → void
Int        → number (with PureScript integer operations where required)
Number     → number
String     → string
Boolean    → boolean
Array a    → Array<a>
```

Unsupported or opaque boundaries use `unknown` where a safe static type is not
available. The backend does not silently use `any` for ordinary generated
values.

## Runtime profiles

The runtime profile controls the generated representation of `Effect`, `Ref`,
`Aff`, async facades, and related modules.

| Profile | Generated effect type | Execution |
| --- | --- | --- |
| `native` | `$runtime.Effect<a> = () => a` | Call the generated thunk |
| `effect` | `$effectRuntime.Effect<a, e, r>` backed by the `effect` package | `runSync`, `runPromise`, or `runPromiseExit` |

The consumer-facing `purs-ts build` obtains the profile from binding metadata.
The backend CLI also accepts `--runtime native|effect`; the default is
`native`. A binding that requires the Effect profile declares, for example:

```json
{
  "requirements": {
    "runtime": "effect",
    "adtRuntime": "taggedRecord"
  },
  "runner": {
    "kind": "effectSync"
  }
}
```

The `effect` profile emits `effect-runtime.ts`, which imports Effect v4
operations from the npm `effect` package. `PursTs.Async`, typed async modules,
`PursTs.Effect`, and `ExceptT` are profile-sensitive and produce a diagnostic
when used with an incompatible profile.

### Effect example

PureScript:

```purescript
module Example.Effect (program) where

import Prelude
import Effect (Effect)
import Effect.Ref as Ref

program :: Effect Int
program = do
  ref <- Ref.new 40
  value <- Ref.read ref
  Ref.write (value + 2) ref
  Ref.read ref
```

With `--runtime effect`, the generated module has this shape:

```typescript
import * as $effectRuntime from "../effect-runtime.ts";

const program$internal: $effectRuntime.Effect<number> =
  $effectRuntime.flatMap(
    $effectRuntime.refMake(40),
    (ref) =>
      $effectRuntime.flatMap(
        $effectRuntime.refGet(ref),
        (value) =>
          $effectRuntime.flatMap(
            $effectRuntime.refSet(ref, (value + 2) | 0),
            () => $effectRuntime.refGet(ref),
          ),
      ),
  );

export const program: $effectRuntime.Effect<number> = program$internal;
```

The host executes the value; importing it does not execute the effect:

```typescript
import { runSync } from "./output/effect-runtime.ts";
import { program } from "./output/Example.Effect/index.ts";

const result = runSync(program); // 42
```

In `native` mode the corresponding effect type is a thunk:

```typescript
export const program: $runtime.Effect<number> = () => 42;

const result = program();
```

## FFI boundary

PureScript declares the capability and TypeScript supplies the host operation:

```purescript
module Browser.Console where

import Effect (Effect)

foreign import log :: String -> Effect Unit
```

The preferred provider is a TypeScript sibling:

```typescript
// Browser/Console.ts
export const log = (message: string) => () => console.log(message);
```

The generated provider is checked for the expected export name and ABI. Relative
imports are rewritten for the generated location. A legacy `.js` sibling is
accepted only as a compatibility input and is copied with an explicit
`@ts-nocheck` header.

## Dead declaration elimination

There are two independent unused-code checks.

### PureScript source warnings

The `purs` compiler can report unused source declarations and imports. Spago can
promote project warnings to errors:

```bash
spago build --strict
```

This is the pre-CoreFn check. It can report an unused PureScript function, but
not an anonymous string literal or a branch that is merely unlikely at runtime.
A strict warning gate can stop generation before the backend runs; it does not
itself perform dead-code elimination.

The direct `purs-ts` path currently invokes `purs compile --codegen corefn,docs`
after asking Spago for source globs. It does not yet propagate Spago's strict
warning policy into that direct invocation. Structured project-warning
propagation is a source-stage follow-up; dependency warnings must remain
separate from application warnings.

### Generated TypeScript liveness

Lowering can create declarations that have no direct PureScript name: internal
helpers, reconstructed type aliases, namespace imports, FFI adapters, and
runtime bindings. The backend removes these before writing `index.ts`:

1. Lower the module into a TypeScript syntax tree.
2. Mark exports, data declarations, re-exports, and public FFI boundaries as
   roots.
3. Walk value references and type references from each root.
4. Repeat through internal declarations until the reachable set is stable.
5. Remove unreachable internal bindings, aliases, and imports.

The walk is structural. It counts identifiers in expression and type positions
but ignores string literals, comments, and quoted property names. Therefore:

```text
string literal  "Link copied"  ≠  identifier  Link
```

Fixture input:

```purescript
importedLabel :: Cleanup.Wrapper -> String
importedLabel _wrapper = "Link copied"

deadBinding :: Int
deadBinding = 1
```

`importedLabel` is public and remains. `deadBinding` is unreachable and its
generated `$internal` declaration is omitted. The fixture is covered by
[`test/stage31-runner.mjs`](./test/stage31-runner.mjs).

Unused value parameters are renamed to `_value` instead of being deleted. Type
parameters are renamed to `_row`, `_childModel`, or `_t0` when generic arity or
explicit type applications require their positions to remain. A public export
or provider boundary is never removed by this pass.

## Output contract

`purs-ts build` writes:

```text
output/
├── <PureScript.Module>/index.ts
├── <PureScript.Module>/foreign.ts
├── <PureScript.Module>/foreign.d.ts
├── runtime.ts
├── native-runtime.ts       # native profile only
├── effect-runtime.ts       # effect profile only
├── entry.ts                # when a binding supplies an entry runner
├── .purs-ts-manifest
└── .purs-ts-graph
```

The output directory is generated and must not be edited manually. The manifest
allows stale backend-owned files to be removed while preserving consumer-owned
files. The cache skips unchanged lowering and provider writes; the graph records
runtime, type-only, and re-export edges.

## Repository layout and development

```text
cli.mjs                         consumer build/dev orchestration
index.js                        generated backend entry wrapper
src/Main.purs                   backend command and generation pipeline
src/PureScript/.../TypeScript/  CoreFn-to-TypeScript lowering
src/PursTs/                     runtime-facing PureScript modules
purescript/PursTs/              package-shipped intrinsic source
src/Mvp/                        language, runtime, and FFI fixtures
test/                           acceptance runners and snapshots
```

Generated `dist/`, `output/`, `.spago/`, and `node_modules/` directories are
ignored. The extracted repository's development `spago.yaml` still references
the shared `backend-es` and `backend-optimizer` packages, so rebuilding the
PureScript CLI currently requires the optimizer workspace package graph. The
installable artifact is bundled from generated `PursTs.Main` output.

The package is not yet published to npm. A release must compile the backend,
bundle `dist/purs-ts.mjs`, pack it, and run the clean-install package test before
publication.
